<a href="SuperMemoElementNo=(2391)">目前可以随意在supermemo当中建立一个种子，开枝散叶了，因为直接到obsidain当中去，然后就有导航能过来

20240617232507</a>
