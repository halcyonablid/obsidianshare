

```dataviewjs
// 解析笔记名称与颜色相关函数（保持原样）
function parseNoteName(name) {
  const match = name.match(/ATOM@(.*?)- (.+)/);
  if (!match) return null;
  
  const addressPart = match[1];
  const namePart = match[2];
  
  const atIndex = addressPart.lastIndexOf('@');
  if (atIndex !== -1) {
    return {
      addressType: addressPart.substring(0, atIndex),
      address: addressPart.substring(atIndex + 1),
      name: namePart
    };
  } else {
    return {
      addressType: '',
      address: addressPart,
      name: namePart
    };
  }
}

// 所有其他辅助函数（保持原样）
function generateColorIndex(addressType, address) {
  const fullAddress = (addressType ? addressType + '@' : '') + address;
  let hash = 0;
  for (let i = 0; i < fullAddress.length; i++) {
    const char = fullAddress.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  hash = Math.abs(hash);
  return hash % colorOptions.length;
}

function isSameFormat(addr1, addr2, ignoreDotsUpTo = 0) {
  const processAddr = (addr, ignoreDots) => {
    let processed = addr.substring(0, ignoreDots).replace(/\./g, '') + addr.substring(ignoreDots);
    return processed.replace(/[A-Z]/g, 'L').replace(/\d+/g, 'N');
  };

  const pattern1 = processAddr(addr1, ignoreDotsUpTo);
  const pattern2 = processAddr(addr2, ignoreDotsUpTo);
  return pattern1 === pattern2;
}

function containsDot(address) { return address.includes('.'); }

function getLengthBeforeFirstDot(address) {
  const dotIndex = address.indexOf('.');
  return dotIndex === -1 ? address.length : dotIndex;
}

function compareAddresses(addr1, addr2) {
  const parts1 = addr1.split('.');
  const parts2 = addr2.split('.');
  const minLen = Math.min(parts1.length, parts2.length);
  
  for (let i = 0; i < minLen; i++) {
    if (parts1[i] !== parts2[i]) {
      if (/^\d+$/.test(parts1[i]) && /^\d+$/.test(parts2[i])) {
        return parseInt(parts1[i]) - parseInt(parts2[i]);
      }
      return parts1[i].localeCompare(parts2[i]);
    }
  }
  return parts1.length - parts2.length;
}

// 颜色选项保持不变
const colorOptions = [
  "钴蓝", "翡翠绿", "奶油色", "米色", "褐灰色", "中棕色", "亮红色", "亮黄色", 
  "亮蓝色", "深紫色", "橙色", "绿色", "粉红色", "金色", "银色", "铜色", 
  "珊瑚红", "孔雀蓝", "薰衣草紫", "玫瑰金", "青铜色", "深绿色", "勃艮第红", 
  "蒂芙尼蓝", "杏色", "石榴红", "鸭蛋青", "芥末黄", "茄子紫", "橄榄绿", 
  "赭石色", "靛蓝"
];

// 硬编码颜色映射（保持原样）
const colorMap = {
  "钴蓝": "rgba(0, 71, 171, 0.1)",
  "翡翠绿": "rgba(80, 200, 120, 0.1)",
  "奶油色": "rgba(255, 253, 208, 0.1)",
  "米色": "rgba(245, 245, 220, 0.1)",
  "褐灰色": "rgba(139, 133, 137, 0.1)",
  "中棕色": "rgba(165, 42, 42, 0.1)",
  "亮红色": "rgba(255, 0, 0, 0.1)",
  "亮黄色": "rgba(255, 255, 0, 0.1)",
  "亮蓝色": "rgba(0, 0, 255, 0.1)",
  "深紫色": "rgba(75, 0, 130, 0.1)",
  "橙色": "rgba(255, 165, 0, 0.1)",
  "绿色": "rgba(0, 128, 0, 0.1)",
  "粉红色": "rgba(255, 192, 203, 0.1)",
  "金色": "rgba(255, 215, 0, 0.1)",
  "银色": "rgba(192, 192, 192, 0.1)",
  "铜色": "rgba(184, 115, 51, 0.1)",
  "珊瑚红": "rgba(255, 127, 80, 0.1)",
  "孔雀蓝": "rgba(51, 161, 201, 0.1)",
  "薰衣草紫": "rgba(230, 230, 250, 0.1)",
  "玫瑰金": "rgba(183, 110, 121, 0.1)",
  "青铜色": "rgba(205, 127, 50, 0.1)",
  "深绿色": "rgba(34, 139, 34, 0.1)",
  "勃艮第红": "rgba(128, 0, 32, 0.1)",
  "蒂芙尼蓝": "rgba(10, 186, 181, 0.1)",
  "杏色": "rgba(251, 206, 177, 0.1)",
  "石榴红": "rgba(196, 30, 58, 0.1)",
  "鸭蛋青": "rgba(224, 255, 255, 0.1)",
  "芥末黄": "rgba(255, 219, 88, 0.1)",
  "茄子紫": "rgba(97, 64, 81, 0.1)",
  "橄榄绿": "rgba(128, 128, 0, 0.1)",
  "赭石色": "rgba(160, 82, 45, 0.1)",
  "靛蓝": "rgba(75, 0, 130, 0.1)",
  "克莱因蓝": "rgba(0, 47, 167, 0.5)"
};

// 调整后的CSS样式 - 修复链接样式问题
const styleEl = dv.el("style", `
  /* 表格基本样式 */
  .custom-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    font-size: 18px;
  }
  
  /* 表头样式 */
  .custom-table th {
    background-color: var(--background-primary);
    padding: 8px 4px;
    text-align: left;
    border-bottom: 2px solid var(--background-modifier-border);
    font-size: 18px;
    font-weight: 600;
    position: sticky;
    top: 0;
    z-index: 10;
    line-height: 1.5;
  }
  
  /* 行样式和行高 */
  .custom-table tr {
    height: 48px;
    line-height: 1.5;
  }
  
  .custom-table tr:hover {
    filter: brightness(0.95);
  }
  
  /* 单元格样式 */
  .custom-table td {
    padding: 8px 4px;
    line-height: 1.5;
  }
  
  /* 编号列样式 */
  .number-column {
    width: 50px;
    text-align: right;
    padding-right: 10px;
    color: var(--text-muted);
    font-weight: 500;
  }
  
  /* 文件名列样式 */
  .filename-column {
    padding: 4px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.5;
  }
  
  /* 链接样式 - 简化版，避免干扰点击功能 */
  .custom-table a.internal-link {
    text-decoration: none;
    font-size: 18px;
    line-height: 1.5;
    font-weight: 500;
  }
  
  /* 加载指示器样式 */
  .loading-indicator {
    position: fixed;
    bottom: 10px;
    right: 10px;
    padding: 6px 8px;
    background: var(--background-primary);
    border: 1px solid var(--background-modifier-border);
    border-radius: 4px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    z-index: 1000;
    display: none;
    font-size: 14px;
  }
  
  /* 文件计数信息 */
  .file-count-info {
    font-size: 14px;
    margin-bottom: 8px;
    color: var(--text-muted);
    line-height: 1.5;
  }
  
  /* 当前活动文件高亮 */
  tr.current-file td {
    background-color: rgba(var(--interactive-accent-rgb), 0.2);
  }
`);

// 创建加载指示器
const loadingIndicator = dv.el("div", "加载中...", {cls: "loading-indicator"});
dv.container.appendChild(loadingIndicator);

// 限制显示条目数量
const MAX_DISPLAY_ITEMS = 5000;

// 获取符合条件的页面
let pages = dv.pages('""')
  .where(p => p.file.name.startsWith("ATOM@") && p.antinet === "atom")
  .sort(p => p.file.name, 'asc');

// 预处理笔记信息
const pageInfo = pages.map(p => {
  const noteName = parseNoteName(p.file.name);
  if (!noteName) return null;
  
  const fullAddress = (noteName.addressType ? noteName.addressType + '@' : '') + noteName.address;
  return {
    page: p,
    noteName: noteName,
    fullAddress: fullAddress,
    hasDot: containsDot(fullAddress),
    indexedKeywords: p['索引关键词已录入'] === true
  };
}).filter(info => info !== null);

// 仅处理要显示的页面
const displayPageInfo = pageInfo.slice(0, MAX_DISPLAY_ITEMS);

// 颜色分配（与原代码相同）
let colorIndex = 0;
let addressFormats = new Map();
let uncoloredPages = [];

// 第一阶段：初步颜色分配
displayPageInfo.forEach((info) => {
  if (info.hasDot) {
    uncoloredPages.push(info);
    return;
  }
  
  let found = false;
  for (let [existingAddress, existingColor] of addressFormats) {
    if (isSameFormat(existingAddress, info.fullAddress)) {
      addressFormats.set(info.fullAddress, existingColor);
      found = true;
      break;
    }
  }
  
  if (!found) {
    addressFormats.set(info.fullAddress, colorIndex);
    colorIndex = (colorIndex + 1) % colorOptions.length;
  }
});

// 第二阶段：处理含点的地址
if (uncoloredPages.length > 0) {
  uncoloredPages.sort((a, b) => compareAddresses(a.fullAddress, b.fullAddress));
  
  while (uncoloredPages.length > 0) {
    const firstPage = uncoloredPages.shift();
    const ignoreDotsUpTo = getLengthBeforeFirstDot(firstPage.fullAddress);
    const colorIdx = generateColorIndex(firstPage.noteName.addressType, firstPage.noteName.address);
    
    addressFormats.set(firstPage.fullAddress, colorIdx);
    
    let remaining = [];
    
    uncoloredPages.forEach(info => {
      if (isSameFormat(firstPage.fullAddress, info.fullAddress, ignoreDotsUpTo)) {
        addressFormats.set(info.fullAddress, colorIdx);
      } else {
        remaining.push(info);
      }
    });
    
    uncoloredPages = remaining;
  }
}

// 预加载功能实现
let preloadQueue = [];
function smartPreload(targetFilePath) {
  // 查找当前文件在列表中的索引
  const fileIndex = displayPageInfo.findIndex(info => 
    info.page.file.path === targetFilePath);
  
  if (fileIndex === -1) return; // 文件不在列表中
  
  // 清空当前预加载队列
  preloadQueue = [];
  
  // 确定预加载范围
  const windowSize = 10; // 前后各10个文件
  const startIdx = Math.max(0, fileIndex - windowSize);
  const endIdx = Math.min(displayPageInfo.length - 1, fileIndex + windowSize);
  
  // 先预加载离中心点近的文件
  for (let distance = 1; distance <= windowSize; distance++) {
    // 先添加后面的文件（更可能按顺序阅读）
    if (fileIndex + distance <= endIdx) {
      preloadQueue.push(fileIndex + distance);
    }
    // 再添加前面的文件
    if (fileIndex - distance >= startIdx) {
      preloadQueue.push(fileIndex - distance);
    }
  }
  
  // 开始预加载
  processBatchPreload();
}

// 批量预加载处理器
function processBatchPreload() {
  if (preloadQueue.length === 0) return;
  
  const nextIndex = preloadQueue.shift();
  const fileInfo = displayPageInfo[nextIndex];
  
  if (fileInfo) {
    try {
      // 预加载文件内容
      app.vault.cachedRead(app.vault.getAbstractFileByPath(fileInfo.page.file.path))
        .catch(() => {/* 忽略预加载错误 */})
        .finally(() => {
          // 继续处理队列中的下一个
          setTimeout(processBatchPreload, 50);
        });
    } catch (e) {
      setTimeout(processBatchPreload, 50);
    }
  } else {
    setTimeout(processBatchPreload, 50);
  }
}

// 高亮当前打开的文件行
function highlightCurrentFile(filePath) {
  // 移除之前的高亮
  document.querySelectorAll('.custom-table tr.current-file').forEach(row => {
    row.classList.remove('current-file');
  });
  
  // 查找匹配行
  const row = document.querySelector(`.custom-table tr[data-path="${filePath}"]`);
  if (row) {
    row.classList.add('current-file');
  }
}

// 构建表格行 - 保持链接简单，不添加太多样式和特殊类
let rows = [];
displayPageInfo.forEach((info, index) => {
  // 获取颜色
  let colorIdx = addressFormats.get(info.fullAddress) || 0;
  let colorName = colorOptions[colorIdx % colorOptions.length];
  let backgroundColor = info.indexedKeywords ? colorMap["克莱因蓝"] : colorMap[colorName];
  
  // 构建行HTML - 保留原始internal-link类，不添加太多样式
  rows.push(`
    <tr id="atom-row-${index}" data-path="${info.page.file.path}" style="background-color: ${backgroundColor};">
      <td class="number-column">${index + 1}</td>
      <td class="filename-column"><a href="${info.page.file.path}" class="internal-link">${info.page.file.name}</a></td>
    </tr>
  `);
});

// 生成完整HTML
let tableHtml = `
<div>
  <p class="file-count-info">显示 ${displayPageInfo.length} 个文件（共 ${pageInfo.length} 个）</p>
  <table class="custom-table">
    <thead>
      <tr>
        <th class="number-column">编号</th>
        <th class="filename-column">文件名</th>
      </tr>
    </thead>
    <tbody>
      ${rows.join('')}
    </tbody>
  </table>
</div>
`;

// 渲染表格
dv.container.innerHTML = tableHtml;

// 添加行点击事件 - 整行可点击，提高操作便捷性
document.querySelectorAll('.custom-table tr[data-path]').forEach(row => {
  row.addEventListener('click', (event) => {
    // 避免与链接点击冲突
    if (event.target.tagName !== 'A') {
      const filePath = row.getAttribute('data-path');
      // 显示加载指示器
      loadingIndicator.style.display = "block";
      // 启动预加载
      smartPreload(filePath);
      // 打开文件
      app.workspace.openLinkText(filePath, "", false);
      // 短暂延迟后隐藏加载指示器
      setTimeout(() => {
        loadingIndicator.style.display = "none";
      }, 200);
    }
  });
});

// 添加监听器以跟踪当前打开的文件
setTimeout(() => {
  if (app && app.workspace) {
    // 监听活动叶片变化
    app.workspace.on('active-leaf-change', (leaf) => {
      if (leaf && leaf.view && leaf.view.file) {
        const currentFilePath = leaf.view.file.path;
        if (currentFilePath && currentFilePath.includes('ATOM@')) {
          // 高亮当前文件行
          highlightCurrentFile(currentFilePath);
          // 启动预加载
          smartPreload(currentFilePath);
        }
      }
    });
    
    // 处理初始加载时的当前文件
    const activeLeaf = app.workspace.activeLeaf;
    if (activeLeaf && activeLeaf.view && activeLeaf.view.file) {
      const currentFilePath = activeLeaf.view.file.path;
      if (currentFilePath && currentFilePath.includes('ATOM@')) {
        highlightCurrentFile(currentFilePath);
        smartPreload(currentFilePath);
      }
    }
  }
}, 1000);

// 初始预加载一些文件
setTimeout(() => {
  // 预加载前20个文件
  for (let i = 0; i < 20 && i < displayPageInfo.length; i++) {
    preloadQueue.push(i);
  }
  processBatchPreload();
}, 500);
```
