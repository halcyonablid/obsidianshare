```dataviewjs
// ===== 基础配置 =====
const CONFIG = {
  targetNode: "ATOM@027F.004", // 目标节点
  maxDepth: 19,               // 最大显示深度
  layout: "LR",               // 图表布局: TB(上到下), LR(左到右)
  debug: false,               // 调试模式
  addInvisibleNodes: true,    // 添加不可见节点控制层级
  showAllDescendants: true,   // 显示所有子孙节点
  showFullIds: true,          // 显示完整的节点ID
  enableZoom: true,           // 启用缩放功能
  initialZoom: 2.0,           // 初始缩放级别
  zoomStep: 0.1               // 缩放步长
};

// ===== 工具函数 =====
// 调试日志 - 改为空函数以提高性能
function debugLog(...args) {
  // 功能已移除以提高性能
}

// 子图生成调试日志 - 改为空函数以提高性能
function subgraphDebugLog(message) {
  // 功能已移除以提高性能
}

// 获取节点点号层级
function getDotLevel(id) { 
  if (!id) return 0; 
  return (id.match(/\./g) || []).length; 
}

// 获取节点加号层级
function getPlusLevel(id) { 
  if (!id) return 0; 
  return (id.match(/\+/g) || []).length; 
}

// 安全的节点ID转换
function safeNodeId(id) {
  return "node_" + id.replace(/[@\.+]/g, function(match) {
    if (match === '+') return "_plus_";
    if (match === '.') return "_";
    if (match === '@') return "_";
    return "_";
  });
}

// 从文件名解析节点信息
function parseFileInfo(fileName) {
  const match = fileName.match(/ATOM@(.*?)- (.+)/);
  
  if (!match) {
    return { id: fileName, name: fileName, hasStateTransition: false };
  }
  
  const id = "ATOM@" + match[1].trim();
  const name = match[2].trim();
  
  // 检查是否包含状态转移符号"+"
  const hasStateTransition = id.includes("+");
  
  // 解析状态转移
  let baseState = null;
  if (hasStateTransition) {
    const plusIndex = id.indexOf("+");
    baseState = id.substring(0, plusIndex);
  }
  
  return { id, name, hasStateTransition, baseState };
}

// 修正后的状态转移关系判断函数
function isStateTransitionRelation(sourceId, targetId) {
  // 如果两个ID相同，则不是状态转移关系
  if (sourceId === targetId) return false;
  
  // 获取纯ID（移除可能的描述部分）
  const dashSourceIndex = sourceId.indexOf('-');
  const pureSourceId = dashSourceIndex > 0 ? sourceId.substring(0, dashSourceIndex) : sourceId;
  
  const dashTargetIndex = targetId.indexOf('-');
  const pureTargetId = dashTargetIndex > 0 ? targetId.substring(0, dashTargetIndex) : targetId;
  
  // 情况1: 直接状态转移关系 (如 ATOM@027F.001.002 -> ATOM@027F.001.002+001)
  if (pureTargetId.startsWith(pureSourceId + "+")) {
    const remainingPart = pureTargetId.substring(pureSourceId.length + 1);
    // 确保"+"后面的部分不包含"+"或"." - 关键修改点
    return !remainingPart.includes("+") && !remainingPart.includes(".");
  }
  
  // 情况2: 多级状态转移关系 (如 ATOM@027F.001.002+001 -> ATOM@027F.001.002+001+001)
  if (pureSourceId.includes("+") && pureTargetId.includes("+")) {
    // 源ID中的加号数量
    const sourcePlusCount = (pureSourceId.match(/\+/g) || []).length;
    // 目标ID中的加号数量
    const targetPlusCount = (pureTargetId.match(/\+/g) || []).length;
    
    // 如果目标比源多一个加号，且目标ID是以源ID+"+"开头的
    if (targetPlusCount === sourcePlusCount + 1 && pureTargetId.startsWith(pureSourceId + "+")) {
      const remainingPart = pureTargetId.substring(pureSourceId.length + 1);
      // 确保"+"后面的部分不包含"." - 关键修改点
      return !remainingPart.includes(".");
    }
  }
  
  return false;
}

// 新增函数：获取状态转移节点的直接来源ID
function getStateTransitionParentId(id) {
  // 如果ID包含"-"字符，只取"-"之前的部分作为实际ID
  const dashIndex = id.indexOf('-');
  const pureId = dashIndex > 0 ? id.substring(0, dashIndex) : id;
  
  // 如果不是状态转移节点，返回null
  if (!pureId.includes("+")) return null;
  
  // 找到最后一个加号的位置
  const lastPlusIndex = pureId.lastIndexOf("+");
  
  // 返回最后一个加号之前的部分（直接来源节点）
  return pureId.substring(0, lastPlusIndex);
}

// 判断是否为子节点关系
function isChildRelation(parentId, childId) {
  // 如果两个ID相同，则不是子节点关系
  if (parentId === childId) return false;
  
  // 只有通过添加"."形成的才是子节点
  if (childId.startsWith(parentId + ".")) {
    const remainingPart = childId.substring(parentId.length + 1);
    // 确保这是直接子节点
    return !remainingPart.includes(".");
  }
  
  return false;
}

// 获取节点的父节点ID
function getParentId(id) {
  // 如果ID包含"-"字符，只取"-"之前的部分作为实际ID
  const dashIndex = id.indexOf('-');
  const pureId = dashIndex > 0 ? id.substring(0, dashIndex) : id;
  
  // 处理状态转移后的多级点号路径 (如 ATOM@027F.001.001+001.002.001)
  if (pureId.includes("+") && pureId.substring(pureId.indexOf("+")).includes(".")) {
    const afterPlusPart = pureId.substring(pureId.indexOf("+")); // 例如: +001.002.001
    
    // 找到最后一个点号的位置
    const lastDotIndex = afterPlusPart.lastIndexOf(".");
    if (lastDotIndex > 0) {
      // 返回到最后一个点号之前的部分
      return pureId.substring(0, pureId.indexOf("+") + lastDotIndex);
    } else {
      // 如果加号后只有一个点号段，返回到加号部分
      return pureId.substring(0, pureId.indexOf("+") + afterPlusPart.indexOf("."));
    }
  }
  
  // 处理多个加号情况 (如 ATOM@027F.001.001+002+001)
  if (pureId.split("+").length > 2) {
    const lastPlusIndex = pureId.lastIndexOf("+");
    return pureId.substring(0, lastPlusIndex);
  }
  
  // 处理单个加号情况 (如 ATOM@027F.001.001+001)
  if (pureId.includes("+")) {
    return pureId.substring(0, pureId.indexOf("+"));
  }
  
  // 处理普通层级关系
  if (pureId.includes(".")) {
    const lastDotIndex = pureId.lastIndexOf(".");
    
    // 检查最后一部分是否含有字母（如ATOM@027F.001.001A）
    const lastPart = pureId.substring(lastDotIndex + 1);
    if (/[A-Za-z]/.test(lastPart) && !lastPart.match(/^[0-9]+[A-Za-z]$/)) {
      // 这是并列节点，不是子节点，查找其并列的节点
      return pureId.substring(0, lastDotIndex);
    }
    
    // 普通情况，如 ATOM@027F.001.001.001 的父节点是 ATOM@027F.001.001
    return pureId.substring(0, lastDotIndex);
  }
  
  return null;
}

// 获取节点层级
function getNodeLevel(id) {
  if (!id) return 0;
  
  // 分别计算点号和加号的数量
  const dotCount = (id.match(/\./g) || []).length;
  const plusCount = (id.match(/\+/g) || []).length;
  
  // 总层级是两者之和
  return dotCount + plusCount;
}

// 获取状态转移的编号部分（最后一个+或.后面的部分）
function getNodeNumber(id) {
  if (!id) return "";
  
  // 对于包含+的ID
  if (id.includes("+")) {
    const lastPlusParts = id.split("+");
    const lastPart = lastPlusParts[lastPlusParts.length - 1];
    
    // 如果最后部分还包含点号，取点号后面的部分
    if (lastPart.includes(".")) {
      const lastDotParts = lastPart.split(".");
      return lastDotParts[lastDotParts.length - 1];
    } else {
      // 否则返回最后一个+后面的部分
      return lastPart;
    }
  }
  
  // 对于只包含.的ID
  if (id.includes(".")) {
    const parts = id.split(".");
    return parts[parts.length - 1];
  }
  
  // 无法确定编号
  return id;
}

// ===== 节点点击滚动功能 =====
// 查找并滚动到右侧视图中的指定文件
function findAndScrollToFileInAOTM(fileName) {
  // 延迟执行，确保DOM已经完全加载
  setTimeout(() => {
    try {
      // 查找右侧边栏中的所有可能的表格视图
      const potentialTables = document.querySelectorAll('.workspace-leaf:not(.mod-active) .view-content table tbody, .workspace-leaf:not(.mod-active) .view-content .custom-table tbody');
      
      if (!potentialTables || potentialTables.length === 0) {
        throw new Error('未找到可能包含文件列表的表格');
      }
      
      // 尝试在每个找到的表格中查找目标行
      let targetRow = null;
      let containingTable = null;
      
      for (const tableBody of potentialTables) {
        const allRows = Array.from(tableBody.querySelectorAll('tr'));
        const foundRow = allRows.find(row => {
          // 检查行内容是否包含文件名
          return row.textContent.includes(fileName);
        });
        
        if (foundRow) {
          targetRow = foundRow;
          containingTable = tableBody;
          break;
        }
      }
      
      // 如果没找到，尝试回退方案
      if (!targetRow) {
        // 查找包含此文件名的任何元素
        const allElements = document.querySelectorAll('.workspace-leaf:not(.mod-active) .view-content *');
        for (const element of allElements) {
          if (element.textContent.includes(fileName)) {
            targetRow = element.closest('tr') || element;
            break;
          }
        }
      }
      
      if (!targetRow) {
        // 使用Obsidian的Notice显示提示
        if (window.Notice) {
          new Notice(`在右侧视图中未找到笔记: ${fileName}`);
        } else {
          console.log(`在右侧视图中未找到笔记: ${fileName}`);
        }
        return;
      }
      
      // 查找包含目标行的滚动容器
      const scrollContainer = targetRow.closest('.workspace-leaf-content') || 
                              targetRow.closest('.view-content') || 
                              document.querySelector('.workspace-split.mod-vertical.mod-root');
      
      if (!scrollContainer) {
        throw new Error('未找到可滚动容器');
      }
      
      // 执行滚动，使目标行居中
      targetRow.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center'
      });
      
      // 添加视觉效果：暂时高亮目标行
      const originalBackground = targetRow.style.backgroundColor;
      const originalTransition = targetRow.style.transition;
      
      targetRow.style.transition = 'background-color 0.8s';
      targetRow.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';  // 黄色高亮
      
      // 3秒后恢复原来的背景色
      setTimeout(() => {
        targetRow.style.backgroundColor = originalBackground;
        targetRow.style.transition = originalTransition;
      }, 3000);
      
      // 显示通知
      let noticeMessage;
      if (containingTable) {
        const allRows = Array.from(containingTable.querySelectorAll('tr'));
        const rowIndex = allRows.indexOf(targetRow) + 1;
        noticeMessage = `已找到并滚动到笔记：${fileName}（第 ${rowIndex} 行 / 共 ${allRows.length} 行）`;
      } else {
        noticeMessage = `已找到并滚动到笔记：${fileName}`;
      }
      
      if (window.Notice) {
        new Notice(noticeMessage);
      } else {
        console.log(noticeMessage);
      }
      
    } catch (error) {
      console.error('滚动定位错误:', error);
      const errorMessage = `查找或滚动过程中发生错误：${error.message}`;
      if (window.Notice) {
        new Notice(errorMessage);
      } else {
        console.error(errorMessage);
      }
    }
  }, 300); // 给DOM加载留出足够时间
}

// 显示提示消息的辅助函数
function showToast(message, type = "info") {
  // 移除可能存在的旧提示
  const existingToast = document.getElementById('mermaid-toast');
  if (existingToast) {
    existingToast.remove();
  }
  
  // 创建提示元素
  const toast = document.createElement('div');
  toast.id = 'mermaid-toast';
  toast.textContent = message;
  
  // 样式设置
  toast.style.cssText = `
    position: fixed;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    padding: 10px 20px;
    background-color: ${type === 'error' ? '#ff3366' : '#333'};
    color: white;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    z-index: 10000;
    font-size: 14px;
    opacity: 0;
    transition: opacity 0.3s ease;
  `;
  
  // 添加到DOM
  document.body.appendChild(toast);
  
  // 显示提示
  setTimeout(() => {
    toast.style.opacity = '1';
    
    // 3秒后淡出
    setTimeout(() => {
      toast.style.opacity = '0';
      
      // 完全淡出后移除
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, 3000);
  }, 10);
}

// ===== 数据收集与处理 =====
// 获取所有文件
function getFiles() {
  try {
    // 使用真实数据 - 查询指定前缀的节点
    return dv.pages()
      .where(p => p.file.name.startsWith(CONFIG.targetNode))
      .sort(p => p.file.name, 'asc')
      .map(p => {
        return {
          file: p.file,
          mermaidViewComplete: p["mermaid视图完成"] === true, // 这是我们上次加的
          mermaidViewHighlight: p["mermaid视图重点"] === true // <<< 增加这一行，用于重点标记
        };
      })
      .array();
  } catch (error) {
    return [];
  }
}


// 获取直接状态转移节点
function getDirectStateTransitions(node, allNodes) {
  return allNodes.filter(n => {
    // 跳过自身
    if (n.id === node.id) return false;
    
    // 使用改进后的函数判断状态转移关系
    return isStateTransitionRelation(node.id, n.id);
  });
}

// 获取所有直接子节点 - 通过"."连接的
function getDirectChildren(node, allNodes) {
  return allNodes.filter(potentialChild => {
    // 跳过自身
    if (potentialChild.id === node.id) return false;
    
    // 只检查通过"."连接的子节点
    if (potentialChild.id.startsWith(node.id + ".")) {
      const remainingPart = potentialChild.id.substring(node.id.length + 1);
      // 确保这是直接子节点
      return !remainingPart.includes(".");
    }
    
    return false;
  });
}

// 获取所有直接点号子节点
function getDirectDotChildren(node, allNodes) {
  return allNodes.filter(n => {
    // 跳过自身
    if (n.id === node.id) return false;
    
    // 确保是通过添加"."形成的直接子节点
    if (n.id.startsWith(node.id + ".")) {
      const remainingPart = n.id.substring(node.id.length + 1);
      // 确保这是直接子节点
      return !remainingPart.includes(".");
    }
    
    return false;
  });
}

// 获取所有点号子孙节点
function getAllDotDescendants(node, allNodes) {
  const descendants = [];
  const queue = [node];
  const processed = new Set([node.id]);
  
  while (queue.length > 0) {
    const currentNode = queue.shift();
    
    // 查找当前节点的所有直接点号子节点
    const dotChildren = getDirectDotChildren(currentNode, allNodes);
    
    // 将找到的子节点添加到结果集中
    dotChildren.forEach(child => {
      if (!processed.has(child.id)) {
        descendants.push(child);
        processed.add(child.id);
        queue.push(child); // 将子节点加入队列，继续处理其子节点
      }
    });
  }
  
  return descendants;
}

// 收集相关节点
function collectRelevantNodes(targetNode, allNodes, maxDepth) {
  const result = new Set([targetNode]);
  
  // 辅助函数：递归收集父节点
  function collectParents(node, depth) {
    if (depth >= maxDepth) return;
    if (!node.parentId) return;
    
    const parent = allNodes.find(n => n.id === node.parentId);
    if (parent) {
      result.add(parent);
      collectParents(parent, depth + 1);
    }
  }
  
  // 辅助函数：递归收集子节点
  function collectChildren(nodeId, depth) {
    if (depth >= maxDepth) return;
    
    // 找出所有直接子节点
    const directChildren = allNodes.filter(n => 
      isChildRelation(nodeId, n.id)
    );
    
    // 添加子节点并继续递归
    directChildren.forEach(child => {
      result.add(child);
      
      // 如果配置为显示所有子孙节点，则递归收集
      if (CONFIG.showAllDescendants) {
        collectChildren(child.id, depth + 1);
      }
    });
  }
  
  // 收集父节点
  collectParents(targetNode, 0);
  
  // 收集子节点
  collectChildren(targetNode.id, 0);
  
  // 收集状态转移节点及相关节点
  function collectStateTransitions() {
    const currentSize = result.size;
    
    // 构建直接状态转移关系映射
    const directTransitionMap = new Map();
    allNodes.filter(node => node.hasStateTransition).forEach(node => {
      const sourceId = getStateTransitionParentId(node.id);
      if (sourceId) {
        if (!directTransitionMap.has(sourceId)) {
          directTransitionMap.set(sourceId, []);
        }
        directTransitionMap.get(sourceId).push(node);
      }
    });
    
    // 遍历当前结果集中的所有节点
    Array.from(result).forEach(node => {
      // 如果节点有状态转移子节点，添加它们
      if (directTransitionMap.has(node.id)) {
        directTransitionMap.get(node.id).forEach(stateNode => {
          result.add(stateNode);
          
          // 收集这个状态转移节点的点号子孙节点
          getAllDotDescendants(stateNode, allNodes).forEach(desc => {
            result.add(desc);
          });
        });
      }
      
      // 如果是状态转移节点，确保其基础状态节点也被收集
      if (node.hasStateTransition) {
        const sourceId = getStateTransitionParentId(node.id);
        if (sourceId) {
          const sourceNode = allNodes.find(n => n.id === sourceId);
          if (sourceNode) {
            result.add(sourceNode);
            
            // 收集源节点的点号子孙节点
            getAllDotDescendants(sourceNode, allNodes).forEach(desc => {
              result.add(desc);
            });
          }
        }
      }
    });
    
    // 如果集合大小有变化，继续迭代
    if (currentSize !== result.size) {
      collectStateTransitions();
    }
  }
  
  // 递归收集所有状态转移关系
  collectStateTransitions();
  
  return Array.from(result);
}

// 创建子图 - 修改后正确处理子孙节点
function createSubgraph(nodeId, relevantNodes, graph, graphData) {
  // 处理带有描述部分的节点ID
  const dashIndex = nodeId.indexOf('-');
  const pureNodeId = dashIndex > 0 ? nodeId.substring(0, dashIndex) : nodeId;
  
  // 创建子图ID
  const subgraphId = `state_${pureNodeId.replace(/[@\.+]/g, "_")}`;
  
  // 如果已经处理过这个子图，直接返回
  if (graph.processedSubgraphs.has(subgraphId)) {
    return false;
  }
  
  // 获取当前节点
  const currentNode = relevantNodes.find(node => node.id === nodeId);
  if (!currentNode) {
    return false;
  }
  
  // 创建子图节点列表（首先包含当前节点）
  const subgraphNodeIds = [currentNode.id];
  
  // 添加所有以当前节点纯ID开头、后跟点号的子孙节点
  relevantNodes.forEach(node => {
    const childDashIndex = node.id.indexOf('-');
    const pureChildId = childDashIndex > 0 ? node.id.substring(0, childDashIndex) : node.id;
    
    // 确保不是自身，且是通过"."连接的子节点
    // 关键：确保子图只包含点号子节点，不包含状态转移节点
    if (node.id !== currentNode.id && pureChildId.startsWith(pureNodeId + ".")) {
      // 检查是否在同一状态转移层级上 - 防止包含不属于当前子图的节点
      const childPlusLevel = getPlusLevel(pureChildId);
      const nodePlusLevel = getPlusLevel(pureNodeId);
      
      if (childPlusLevel === nodePlusLevel) {
        subgraphNodeIds.push(node.id);
      }
    }
  });
  
  // 创建节点层级映射 - 基于点号数量计算层级
  const nodeLevelMap = new Map();
  subgraphNodeIds.forEach(id => {
    // 处理可能的描述部分
    const idDashIndex = id.indexOf('-');
    const pureId = idDashIndex > 0 ? id.substring(0, idDashIndex) : id;
    
    // 计算该节点在当前子图内的相对层级 - 只考虑点号
    const dotLevel = getDotLevel(pureId) - getDotLevel(pureNodeId);
    nodeLevelMap.set(id, dotLevel + 1); // +1 是因为根节点在第一层
  });
  
  // 添加子图内部边（父子关系）
  const internalEdges = [];
  
  // 按层级排序节点，确保先处理浅层级节点
  const sortedNodes = [...subgraphNodeIds].sort((a, b) => 
    nodeLevelMap.get(a) - nodeLevelMap.get(b)
  );
  
  // 为每个节点找到其直接父节点
  for (const id of sortedNodes) {
    // 跳过根节点
    if (id === nodeId) continue;
    
    // 获取当前节点的父节点ID
    const parentId = getParentId(id);
    
    // 检查父节点是否在子图内
    if (parentId && subgraphNodeIds.includes(parentId)) {
      // 创建标准化的边键
      const sourceSafeId = safeNodeId(parentId);
      const targetSafeId = safeNodeId(id);
      const globalEdgeKey = `${sourceSafeId}->${targetSafeId}`;
      
      // 添加到子图内部边
      if (!graph.processedEdges) {
        graph.processedEdges = new Set(); // 确保集合存在
      }
      
      if (!graph.processedEdges.has(globalEdgeKey)) {
        internalEdges.push({
          source: parentId,
          target: id
        });
        graph.processedEdges.add(globalEdgeKey);
      }
    }
  }
  
  // 添加子图
  graphData.subgraphs.push({
    id: subgraphId,
    label: `${nodeId} 状态`,
    nodes: subgraphNodeIds,
    edges: internalEdges,
    baseNode: nodeId,
    nodeLevels: nodeLevelMap
  });
  
  graph.processedSubgraphs.add(subgraphId);
  
  return true;
}


// 构建状态转移图 - 完整修改版本
function buildStateTransitionGraph(targetNode, allNodes, maxDepth) {
  // 从目标节点开始，找出所有相关节点
  const relevantNodes = collectRelevantNodes(targetNode, allNodes, maxDepth);
  
  // 图表管理数据
  const graph = {
    processedIds: new Set(),              // 已处理的节点ID
    processedSubgraphs: new Set(),        // 已处理的子图ID
    processedEdges: new Set(),            // 统一存储所有已处理的边
    processedInvisibleEdges: new Set()    // 已处理的不可见边
  };
  
  // 最终图形数据
  const graphData = {
    nodes: [],          // 所有节点
    edges: [],          // 边
    subgraphs: [],      // 子图
    invisibleNodes: [], // 不可见节点
    processingSteps: [] // 用于记录处理步骤
  };
  
  // 构建直接状态转移关系映射
  const directSourceMap = new Map();
  relevantNodes.filter(node => node.hasStateTransition).forEach(node => {
    const sourceId = getStateTransitionParentId(node.id);
    if (sourceId) {
      directSourceMap.set(node.id, sourceId);
    }
  });
  
  // 获取纯ID（移除可能的描述部分）
  function getPureId(id) {
    const dashIndex = id.indexOf('-');
    return dashIndex > 0 ? id.substring(0, dashIndex) : id;
  }
  
  // 检查是否应该创建边
  function shouldCreateEdge(source, target) {
    // 获取纯ID
    const pureSource = getPureId(source);
    const pureTarget = getPureId(target);
    
    // 如果目标节点在某个子图中但不是根节点，则检查源节点是否也在同一子图中
    for (const subgraph of graphData.subgraphs) {
      const pureBaseNode = getPureId(subgraph.baseNode);
      
      // 检查纯目标ID是否在子图中
      const targetInSubgraph = subgraph.nodes.some(nodeId => 
        getPureId(nodeId) === pureTarget
      );
      
      // 如果目标在子图内但不是子图的根节点
      if (targetInSubgraph && pureTarget !== pureBaseNode) {
        // 检查源节点是否在同一子图内
        const sourceInSubgraph = subgraph.nodes.some(nodeId => 
          getPureId(nodeId) === pureSource
        );
        
        return sourceInSubgraph;
      }
    }
    
    // 默认允许创建边
    return true;
  }
  
  // 确保边处理集合存在
  if (!graph.processedEdges) {
    graph.processedEdges = new Set();
  }
  
  // 统一的边添加函数
  function addEdge(source, target, type) {
    const sourceSafeId = safeNodeId(source);
    const targetSafeId = safeNodeId(target);
    const edgeKey = `${sourceSafeId}->${targetSafeId}`;
    
    // 检查边是否已经存在
    if (graph.processedEdges.has(edgeKey)) {
      return false;
    }
    
    // 检查是否应该创建这条边
    if (!shouldCreateEdge(source, target)) {
      return false;
    }
    
    // 添加边并记录
    graphData.edges.push({
      source: source,
      target: target,
      type: type
    });
    
    graph.processedEdges.add(edgeKey);
    return true;
  }
  
  // 记录处理步骤
  function recordStep(step, details) {
    if (CONFIG.debug) {
      graphData.processingSteps.push({ step, details });
    }
  }
  
  // 步骤1: 首先绘制所有不包含"+"的普通节点
  recordStep("1", "绘制所有普通节点（不包含'+'）");
  
  const regularNodes = relevantNodes.filter(node => !node.hasStateTransition);
  
  regularNodes.forEach(node => {
    graphData.nodes.push(node);
    graph.processedIds.add(node.id);
    
    // 添加父子关系边
    if (node.parentId && !node.parentId.includes("+")) {
      const parentNode = regularNodes.find(n => n.id === node.parentId);
      if (parentNode) {
        addEdge(node.parentId, node.id, "hierarchy");
      }
    }
  });
  
  // 步骤2: 按照状态转移层级处理带"+"的状态转移节点
  recordStep("2", "按状态转移层级处理带'+'的状态转移节点");
  
  const stateTransitionNodes = relevantNodes.filter(node => node.hasStateTransition);
  
  // 按层级排序状态转移节点
  stateTransitionNodes.sort((a, b) => {
    // 先按加号数量排序
    const aPlusCount = getPlusLevel(a.id);
    const bPlusCount = getPlusLevel(b.id);
    
    if (aPlusCount !== bPlusCount) {
      return aPlusCount - bPlusCount;
    }
    
    // 如果加号数量相同，按点号数量排序
    const aDotCount = getDotLevel(a.id);
    const bDotCount = getDotLevel(b.id);
    
    if (aDotCount !== bDotCount) {
      return aDotCount - bDotCount;
    }
    
    // 如果两者都相同，按照ID字母顺序排序
    return a.id.localeCompare(b.id);
  });
  
  // 需要添加不可见节点控制层级的计数器
  let invisibleNodeCounter = 1;
  
  // 处理循环
  let unprocessedNodes = [...stateTransitionNodes];
  let iterationCount = 1;
  
  // 存储每个状态转移层级的最低节点
  const lowestNodesPerLevel = new Map();
  
  while (unprocessedNodes.length > 0) {
    recordStep(`迭代${iterationCount}`, `剩余未处理节点: ${unprocessedNodes.length}`);
    
    // 找到层级最小的尚未处理的带"+"的节点
    const currentNode = unprocessedNodes[0];
    
    // 使用directSourceMap获取直接来源节点，而不是baseState
    const directSourceId = directSourceMap.get(currentNode.id) || currentNode.baseState;
    const directSourceNode = relevantNodes.find(n => n.id === directSourceId);
    
    if (directSourceNode) {
      // 确保直接来源节点已添加到图中
      if (!graph.processedIds.has(directSourceId)) {
        graphData.nodes.push(directSourceNode);
        graph.processedIds.add(directSourceId);
      }
      
      // 为直接来源节点创建子图（如果尚未创建）
      if (!graph.processedSubgraphs.has(`state_${directSourceId.replace(/[@\.+]/g, "_")}`)) {
        createSubgraph(directSourceId, relevantNodes, graph, graphData);
      }
      
      // 添加当前状态转移节点到图中
      if (!graph.processedIds.has(currentNode.id)) {
        graphData.nodes.push(currentNode);
        graph.processedIds.add(currentNode.id);
      }
      
      // 用箭头连接直接来源节点到状态转移节点
      addEdge(directSourceId, currentNode.id, "stateTransition");
      
      // 为状态转移节点创建子图
      const hasChildren = relevantNodes.some(n => 
        n.id !== currentNode.id && (
          n.id.startsWith(currentNode.id + ".") || 
          (n.hasStateTransition && directSourceMap.get(n.id) === currentNode.id)
        )
      );
      
      if (hasChildren) {
        createSubgraph(currentNode.id, relevantNodes, graph, graphData);
        
        // 处理直接子节点
        const directChildren = getDirectChildren(currentNode, relevantNodes);
        if (directChildren.length > 0) {
          directChildren.forEach(child => {
            if (!graph.processedIds.has(child.id)) {
              graphData.nodes.push(child);
              graph.processedIds.add(child.id);
            }
          });
        }
      }
      
      // 层级控制 - 改进版本
      if (CONFIG.addInvisibleNodes) {
        // 当前节点的加号层级
        const currentPlusLevel = getPlusLevel(currentNode.id);
        
        if (currentPlusLevel > 1) {  // 对于非首层状态转移节点
          // 找到直接来源节点对应的子图
          const sourceSubgraph = graphData.subgraphs.find(sg => sg.baseNode === directSourceId);
          
          if (sourceSubgraph) {
            // 查找子图中的最低层级节点
            let lowestNode = null;
            let maxDotLevel = -1;
            
            sourceSubgraph.nodes.forEach(nodeId => {
              const dotLevel = getDotLevel(nodeId);
              if (dotLevel > maxDotLevel) {
                maxDotLevel = dotLevel;
                lowestNode = nodeId;
              }
            });
            
            // 如果找到了最低节点，添加不可见节点控制层级
            if (lowestNode) {
              const invisibleNodeId = `invisible${invisibleNodeCounter++}`;
              graphData.invisibleNodes.push(invisibleNodeId);
              
              // 添加控制层级的边
              addEdge(lowestNode, invisibleNodeId, "invisible");
              addEdge(invisibleNodeId, currentNode.id, "invisible");
              
              recordStep(`层级控制${iterationCount}`, `添加不可见节点控制层级: ${lowestNode} -> ${invisibleNodeId} -> ${currentNode.id}`);
              
              // 记录当前层级的最低节点
              lowestNodesPerLevel.set(currentPlusLevel, currentNode.id);
            }
          }
        } else {
          // 记录首层状态转移节点
          lowestNodesPerLevel.set(currentPlusLevel, currentNode.id);
        }
      }
    }
    
    // 更新未处理节点列表
    graph.processedIds.add(currentNode.id);
    unprocessedNodes = stateTransitionNodes.filter(n => !graph.processedIds.has(n.id));
    
    iterationCount++;
  }
  
  // 处理完所有节点后，添加额外的层级控制
  if (CONFIG.addInvisibleNodes) {
    // 确保每个状态转移子图都有合适的层级控制
    graphData.subgraphs.forEach((subgraph, index) => {
      const baseNode = subgraph.baseNode;
      
      // 跳过非状态转移节点的子图
      if (!baseNode.includes("+")) return;
      
      // 检查该子图的根节点是否已经有不可见节点控制
      const hasInvisibleControl = graphData.edges.some(edge => 
        edge.type === "invisible" && edge.target === baseNode
      );
      
      if (!hasInvisibleControl) {
        // 获取此状态转移节点的直接来源节点
        const directSourceId = directSourceMap.get(baseNode);
        
        if (directSourceId) {
          // 查找来源节点对应的子图
          const sourceSubgraph = graphData.subgraphs.find(sg => sg.baseNode === directSourceId);
          
          if (sourceSubgraph) {
            // 查找来源子图中的最低层级节点
            let lowestNode = null;
            let maxDotLevel = -1;
            
            sourceSubgraph.nodes.forEach(nodeId => {
              const dotLevel = getDotLevel(nodeId);
              if (dotLevel > maxDotLevel) {
                maxDotLevel = dotLevel;
                lowestNode = nodeId;
              }
            });
            
            // 如果找到了最低节点，添加不可见节点控制
            if (lowestNode) {
              const invisibleNodeId = `invisible${invisibleNodeCounter++}`;
              graphData.invisibleNodes.push(invisibleNodeId);
              
              // 添加控制层级的边
              addEdge(lowestNode, invisibleNodeId, "invisible");
              addEdge(invisibleNodeId, baseNode, "invisible");
              
              recordStep("额外层级控制", `添加不可见节点控制层级: ${lowestNode} -> ${invisibleNodeId} -> ${baseNode}`);
            }
          }
        }
      }
    });
  }
  
  // 最后一次过滤清理不应该存在的边
  graphData.edges = graphData.edges.filter(edge => {
    return shouldCreateEdge(edge.source, edge.target);
  });
  
  recordStep("完成", `图表构建完成: ${graphData.nodes.length}个节点, ${graphData.edges.length}条边, ${graphData.subgraphs.length}个子图`);
  
  return graphData;
}



// ===== Mermaid代码生成 =====
// 生成Mermaid图表代码
function generateMermaidCode(graph, clickCallback) {
let code = `flowchart ${CONFIG.layout}\n`;
   code += "  %% 节点样式定义\n";
  code += "  classDef normal fill:#ddf,stroke:#333,stroke-width:1px\n";
  code += "  classDef stateTransition fill:#ddf,stroke:#333,stroke-width:1px\n";
  code += "  classDef baseState fill:#dfd,stroke:#393,stroke-width:1px\n";
  code += "  classDef invisible fill:none,stroke:none\n";
  code += " classDef completed fill:#ccc,stroke:#666,stroke-width:1px,color:#333\n";// 上次加的
  code += "  classDef highlighted fill:#F37021,stroke:#C05000,stroke-width:1.5px,color:white\n"; // <<< 增加这一行
// ...

  // 定义所有节点
  code += "  %% 节点定义 - 普通节点\n";
  // 普通节点
  graph.nodes.filter(node => !node.hasStateTransition).forEach(node => {
    const safeId = safeNodeId(node.id);
    
    // 处理节点名称，实现自动分行
    let nodeName = node.name;
    if (nodeName.length > 20) {
      // 使用<br/>标签为长文本添加换行（优先在标点符号处换行）
      nodeName = nodeName.replace(/(.{15,20})([\s,\.，。;；:：!！?？])/g, '$1$2<br/>');
      
      // 如果没有找到合适的断点进行换行，则强制在约20个字符处换行
      if (!nodeName.includes('<br/>') && nodeName.length > 20) {
        // 按照大约20个字符分段
        const chunks = [];
        for (let i = 0; i < nodeName.length; i += 20) {
          chunks.push(nodeName.substring(i, Math.min(i + 20, nodeName.length)));
        }
        nodeName = chunks.join('<br/>');
      }
    }
    
    // 显示完整节点ID和名称
    let displayLabel = CONFIG.showFullIds 
      ? `${node.id}<br/>${nodeName}` 
      : nodeName;
    
    code += `  ${safeId}["${displayLabel}"]\n`;
  });

  // 状态转移节点
  code += "  %% 节点定义 - 状态转移节点\n";
  graph.nodes.filter(node => node.hasStateTransition).forEach(node => {
    const safeId = safeNodeId(node.id);
    
    // 获取状态转移部分（最后一个+后面的内容）
    const transitionPart = getNodeNumber(node.id);
    
    // 处理节点名称，实现自动分行
    let nodeName = node.name;
    if (nodeName.length > 20) {
      // 使用<br/>标签为长文本添加换行（优先在标点符号处换行）
      nodeName = nodeName.replace(/(.{15,20})([\s,\.，。;；:：!！?？])/g, '$1$2<br/>');
      
      // 如果没有找到合适的断点进行换行，则强制在约20个字符处换行
      if (!nodeName.includes('<br/>') && nodeName.length > 20) {
        // 按照大约20个字符分段
        const chunks = [];
        for (let i = 0; i < nodeName.length; i += 20) {
          chunks.push(nodeName.substring(i, Math.min(i + 20, nodeName.length)));
        }
        nodeName = chunks.join('<br/>');
      }
    }
    
    // 显示完整节点ID和名称
    let displayLabel = CONFIG.showFullIds 
      ? `${node.id}<br/>${transitionPart}→ ${nodeName}` 
      : `${transitionPart}→ ${nodeName}`;
    
    code += `  ${safeId}["${displayLabel}"]\n`;
  });
  
  // 不可见节点
  if (CONFIG.addInvisibleNodes) {
    code += "  %% 控制层级的辅助不可见节点\n";
    graph.invisibleNodes.forEach(id => {
      code += `  ${id}[" "]\n`;
    });
  }
  
  // 子图定义
  if (graph.subgraphs.length > 0) {
    code += "  %% 子图定义\n";
    graph.subgraphs.forEach(subgraph => {
      code += `  subgraph ${subgraph.id}["${subgraph.label}"]\n`;
      
      // 添加子图内部边
      const processedEdgeKeys = new Set();
      subgraph.edges.forEach(edge => {
        const sourceSafeId = safeNodeId(edge.source);
        const targetSafeId = safeNodeId(edge.target);
        const edgeKey = `${sourceSafeId}->${targetSafeId}`;
        
        if (!processedEdgeKeys.has(edgeKey)) {
          code += `    ${sourceSafeId} --> ${targetSafeId}\n`;
          processedEdgeKeys.add(edgeKey);
        }
      });
      
      // 如果没有内部边，仅列出节点
      if (subgraph.edges.length === 0) {
        subgraph.nodes.forEach(nodeId => {
          const safeId = safeNodeId(nodeId);
          code += `    ${safeId}\n`;
        });
      }
      
      code += "  end\n";
    });
  }
  
  // 收集所有子图内部边的源-目标对
  const subgraphEdgeSet = new Set();
  graph.subgraphs.forEach(sg => {
    sg.edges.forEach(edge => {
      const sourceSafeId = safeNodeId(edge.source);
      const targetSafeId = safeNodeId(edge.target);
      // 使用标准化的格式存储边
      subgraphEdgeSet.add(`${sourceSafeId}->${targetSafeId}`);
    });
  });
  
  // 定义常规边（子图外的）
  code += "  %% 边定义 - 普通层级关系\n";
  const processedEdgeKeys = new Set();
  
  graph.edges.filter(edge => {
    // 排除子图内部边和不可见边
    if (edge.type === "invisible") return false;
    if (edge.type === "stateTransition") return false;
    
    // 使用标准化的格式检查是否是子图内部边
    const sourceSafeId = safeNodeId(edge.source);
    const targetSafeId = safeNodeId(edge.target);
    const edgeKey = `${sourceSafeId}->${targetSafeId}`;
    
    return !subgraphEdgeSet.has(edgeKey);
  }).forEach(edge => {
    const sourceSafeId = safeNodeId(edge.source);
    const targetSafeId = safeNodeId(edge.target);
    const edgeKey = `${sourceSafeId}->${targetSafeId}`;
    
    if (!processedEdgeKeys.has(edgeKey)) {
      code += `  ${sourceSafeId} --> ${targetSafeId}\n`;
      processedEdgeKeys.add(edgeKey);
    }
  });
  
  // 不可见边，用于控制层级
  if (CONFIG.addInvisibleNodes) {
    code += "  %% 使用不可见节点控制层级\n";
    graph.edges.filter(edge => edge.type === "invisible").forEach(edge => {
      const sourceSafeId = edge.source.startsWith("invisible") 
        ? edge.source 
        : safeNodeId(edge.source);
      const targetSafeId = edge.target.startsWith("invisible") 
        ? edge.target 
        : safeNodeId(edge.target);
      
      const edgeKey = `${sourceSafeId}->${targetSafeId}`;
      if (!processedEdgeKeys.has(edgeKey)) {
        code += `  ${sourceSafeId} -.-> ${targetSafeId}\n`;
        processedEdgeKeys.add(edgeKey);
      }
    });
  }
  
  // 状态转移边 - 确保不重复添加子图内已存在的边
  code += "  %% 边定义 - 状态转移关系\n";
  graph.edges.filter(edge => {
    // 只处理状态转移边
    if (edge.type !== "stateTransition") return false;
    
    // 使用标准化的格式检查是否是子图内部边
    const sourceSafeId = safeNodeId(edge.source);
    const targetSafeId = safeNodeId(edge.target);
    const edgeKey = `${sourceSafeId}->${targetSafeId}`;
    
    return !subgraphEdgeSet.has(edgeKey);
  }).forEach(edge => {
    const sourceSafeId = safeNodeId(edge.source);
    const targetSafeId = safeNodeId(edge.target);
    const edgeKey = `${sourceSafeId}->${targetSafeId}`;
    
    if (!processedEdgeKeys.has(edgeKey)) {
      code += `  ${sourceSafeId} --> ${targetSafeId}\n`;
      processedEdgeKeys.add(edgeKey);
    }
  });
  
// 应用样式
// 应用样式
code += "  %% 应用样式\n";
graph.nodes.forEach(node => {
  const safeId = safeNodeId(node.id);
  
  if (node.mermaidViewHighlight) { // <<< 增加这个新的 if 判断，放在最前面
    code += `  class ${safeId} highlighted\n`;
  } else if (node.mermaidViewComplete) { // <<< 上次加的判断
    code += `  class ${safeId} completed\n`;
  } else if (node.id === CONFIG.targetNode) { // <<< 原有的判断
    code += `  class ${safeId} baseState\n`;
  } else if (node.hasStateTransition) {
    code += `  class ${safeId} stateTransition\n`;
  } else {
    // 检查是否为子图中的基础状态节点
    const isBaseState = graph.subgraphs.some(sg => sg.baseNode === node.id);
    
    if (isBaseState) {
      code += `  class ${safeId} baseState\n`;
    } else {
      code += `  class ${safeId} normal\n`;
    }
  }
});



  
  // 不可见节点样式
  if (CONFIG.addInvisibleNodes) {
    graph.invisibleNodes.forEach(id => {
      code += `  class ${id} invisible\n`;
    });
  }
  
  // ===== 为可点击节点添加点击事件 =====
  if (typeof clickCallback === 'function') {
    // 创建节点ID到节点对象的映射，供点击回调使用
    const nodeIdMap = {};
    graph.nodes.forEach(node => {
      const safeId = safeNodeId(node.id);
      nodeIdMap[safeId] = node;
    });
    
    // 存储生成的ID映射，供外部使用
    window.stateTransitionNodeIdMap = nodeIdMap;
    
    // 收集所有有文件名的可点击节点
    const clickableNodes = graph.nodes
      .filter(node => node.fileName) // 只有有文件名的节点才是可点击的
      .map(node => safeNodeId(node.id));
    
    // 批量添加点击事件
    if (clickableNodes.length > 0) {
      // 保存回调函数到全局作用域
    // 批量添加点击事件 - 使用逗号分隔语法
    
window.stateTransitionNodeClickCallback = clickCallback;
code += "  %% 点击事件\n";
code += `  click ${clickableNodes.join(',')} stateTransitionNodeClickCallback\n`;

      // 添加可点击样式
      code += "  %% 可点击节点样式\n";
      code += "  classDef clickable cursor:pointer\n";
      code += `  class ${clickableNodes.join(',')} clickable\n`;
    }
  }
  
  // 添加处理步骤记录
  if (CONFIG.debug && graph.processingSteps && graph.processingSteps.length > 0) {
    code += "\n  %% 处理步骤记录\n";
    graph.processingSteps.forEach(step => {
      code += `  %% ${step.step}: ${step.details}\n`;
    });
  }
  
  return code;
}

// ===== UI 和主程序 =====
// 创建用户界面
function createUI(container) {
  // 清除现有内容
  container.empty();
  
  // 标题
  container.createEl("h3", { text: "状态转移节点关系图" });
  
  // 设置面板
  const settingsDiv = container.createEl("div", { cls: "settings-panel" });
  settingsDiv.style.marginBottom = "15px";
  settingsDiv.style.padding = "10px";
  settingsDiv.style.backgroundColor = "#f5f5f5";
  settingsDiv.style.borderRadius = "5px";
  
  // 目标节点输入
  const nodeInput = settingsDiv.createEl("input", { 
    type: "text",
    value: CONFIG.targetNode,
    placeholder: "输入目标节点ID"
  });
  nodeInput.style.width = "200px";
  nodeInput.style.marginRight = "15px";
  
  // 深度设置
  const depthInput = settingsDiv.createEl("input", {
    type: "number",
    value: CONFIG.maxDepth,
    attr: { min: 1, max: 30 }
  });
  depthInput.style.width = "50px";
  depthInput.style.marginRight = "15px";
  
  // 布局选择
  const layoutSelect = settingsDiv.createEl("select");
  ["TB", "LR", "RL", "BT"].forEach(dir => {
    const option = layoutSelect.createEl("option", { text: dir });
    if (dir === CONFIG.layout) option.selected = true;
  });
  layoutSelect.style.marginRight = "15px";
  
  // 添加标签
  settingsDiv.insertBefore(document.createTextNode("目标节点: "), nodeInput);
  settingsDiv.insertBefore(document.createTextNode(" 最大深度: "), depthInput);
  settingsDiv.insertBefore(document.createTextNode(" 布局: "), layoutSelect);
  
  // 创建新行
  settingsDiv.createEl("br");
  
  // 添加不可见节点选项
  const invisibleCheck = settingsDiv.createEl("input", { 
    type: "checkbox",
    checked: CONFIG.addInvisibleNodes
  });
  invisibleCheck.style.marginRight = "5px";
  
  // 显示所有子孙节点选项
  const showAllCheck = settingsDiv.createEl("input", { 
    type: "checkbox",
    checked: CONFIG.showAllDescendants
  });
  showAllCheck.style.marginRight = "5px";
  
  // 显示完整ID选项
  const showFullIdsCheck = settingsDiv.createEl("input", { 
    type: "checkbox",
    checked: CONFIG.showFullIds
  });
  showFullIdsCheck.style.marginRight = "5px";
  
  // 启用缩放选项
  const zoomCheck = settingsDiv.createEl("input", { 
    type: "checkbox",
    checked: CONFIG.enableZoom
  });
  zoomCheck.style.marginRight = "5px";
  
  // 调试模式选项
  const debugCheck = settingsDiv.createEl("input", { 
    type: "checkbox",
    checked: CONFIG.debug
  });
  debugCheck.style.marginRight = "5px";
  
  // 添加标签
  settingsDiv.insertBefore(document.createTextNode("添加不可见节点: "), invisibleCheck);
  settingsDiv.insertBefore(document.createTextNode(" 显示所有子孙节点: "), showAllCheck);
  settingsDiv.insertBefore(document.createTextNode(" 显示完整ID: "), showFullIdsCheck);
  settingsDiv.insertBefore(document.createTextNode(" 启用缩放: "), zoomCheck);
  settingsDiv.insertBefore(document.createTextNode(" 调试模式: "), debugCheck);
  
  // 创建新行
  settingsDiv.createEl("br");
  
  // 更新按钮
  const updateButton = settingsDiv.createEl("button", { text: "更新图表" });
  updateButton.style.marginTop = "10px";
  
  // 说明信息
  const infoDiv = container.createEl("div", { cls: "info-panel" });
  infoDiv.style.marginBottom = "10px";
  infoDiv.style.fontSize = "0.9em";
  infoDiv.style.color = "#666";
  infoDiv.innerHTML = `
    <details>
      <summary style="cursor:pointer;color:#0074d9;">查看使用说明</summary>
      <p><b>节点交互功能:</b></p>
      <ul>
        <li><b>点击节点</b>: 点击图表中的任何节点，会自动滚动右侧边栏到对应的笔记位置</li>
        <li><b>高亮显示</b>: 找到的笔记行会暂时高亮显示，方便识别</li>
        <li><b>状态提示</b>: 点击后会显示操作结果的提示信息</li>
      </ul>
      <p>本图表使用循环迭代方式绘制状态转移关系，绘制逻辑为：</p>
      <ol>
        <li>首先绘制所有不包含"+"的普通节点</li>
        <li>然后按照循环迭代处理带"+"的状态转移节点:
          <ul>
            <li>a. 找到层级最小的尚未绘制的带"+"的节点</li>
            <li>b. 找到它的直接来源节点（最后一个"+"前的部分）</li>
            <li>c. 将来源节点及其所有子孙节点（使用"."连接的）放入一个subgraph中</li>
            <li>d. 用虚线箭头连接来源节点到状态转移节点</li>
            <li>e. 为状态转移节点创建子图，包含其点号子节点</li>
            <li>f. 重复以上步骤，直到所有带"+"的节点都被处理</li>
          </ul>
        </li>
      </ol>
      <p>节点关系说明:</p>
      <ul>
        <li>只有在编号末尾添加<b>新的"."</b>才产生子级节点</li>
        <li>在编号末尾添加<b>字母A</b>或<b>递增数字</b>都是创建<b>并列节点</b>，不是子节点</li>
        <li>添加<b>"+"</b>表示<b>状态转移关系</b></li>
      </ul>
      <p>图例说明:</p>
      <ul>
        <li><b>蓝色背景节点</b>: 普通节点</li>
        <li><b>绿色背景节点</b>: 基础状态节点</li>
        <li><b>黄色背景节点</b>: 状态转移节点(显示为"编号→名称"格式)</li>
        <li><b>实线箭头</b>: 普通层级关系</li>
        <li><b>虚线箭头</b>: 状态转移关系</li>
        <li><b>绿色方框</b>: 包含基础状态及其点号子节点的子图</li>
        <li><b>可点击节点</b>: 鼠标悬停时显示为手型光标，点击可导航到对应笔记</li>
      </ul>
      <p>缩放操作说明:</p>
      <ul>
        <li><b>放大/缩小按钮</b>: 点击按钮放大或缩小图表</li>
        <li><b>重置按钮</b>: 恢复原始大小</li>
        <li><b>键盘+鼠标</b>: Ctrl+滚轮进行图表缩放</li>
        <li><b>拖拽</b>: Alt+左键拖拽或中键拖拽进行平移</li>
      </ul>
    </details>
  `;
  
  // 状态信息
  const statusDiv = container.createEl("div", { cls: "status-info" });
  statusDiv.style.marginBottom = "10px";
  statusDiv.style.fontSize = "0.9em";
  
  // 图表容器
  const diagramContainer = container.createEl("div", { cls: "diagram-container" });
  diagramContainer.style.border = "1px solid #ccc";
  diagramContainer.style.padding = "10px";
  diagramContainer.style.minHeight = "500px";
  diagramContainer.style.position = "relative";
  diagramContainer.style.overflow = "auto";
  diagramContainer.style.maxHeight = "900vh"; // 限制最大高度
  
  // 代码切换按钮
  const toggleButton = container.createEl("button", { text: "显示/隐藏Mermaid代码" });
  toggleButton.style.marginTop = "10px";
  
  // 代码容器
  const codeContainer = container.createEl("div", { cls: "code-container" });
  codeContainer.style.display = "none";
  codeContainer.style.border = "1px solid #ccc";
  codeContainer.style.padding = "10px";
  codeContainer.style.marginTop = "10px";
  codeContainer.style.backgroundColor = "#f8f8f8";
  codeContainer.style.fontFamily = "monospace";
  codeContainer.style.fontSize = "0.9em";
  codeContainer.style.overflow = "auto";
  codeContainer.style.maxHeight = "300px";
  codeContainer.style.whiteSpace = "pre";
  
  // 代码复制按钮
  const copyButton = container.createEl("button", { text: "复制代码" });
  copyButton.style.marginTop = "5px";
  copyButton.style.display = "none";
  
  // 添加缩放控制
  const zoomControls = CONFIG.enableZoom ? setupZoomControls(container, diagramContainer) : null;
  
  // 更新按钮事件
  updateButton.addEventListener("click", () => {
    CONFIG.targetNode = nodeInput.value;
    CONFIG.maxDepth = parseInt(depthInput.value);
    CONFIG.layout = layoutSelect.value;
    CONFIG.addInvisibleNodes = invisibleCheck.checked;
    CONFIG.showAllDescendants = showAllCheck.checked;
    CONFIG.showFullIds = showFullIdsCheck.checked;
    CONFIG.enableZoom = zoomCheck.checked;
    CONFIG.debug = debugCheck.checked;
    
    renderDiagram(container, statusDiv, diagramContainer, codeContainer, zoomControls);
  });
  
  // 切换代码显示
  toggleButton.addEventListener("click", () => {
    if (codeContainer.style.display === "none") {
      codeContainer.style.display = "block";
      copyButton.style.display = "inline-block";
    } else {
      codeContainer.style.display = "none";
      copyButton.style.display = "none";
    }
  });
  
  // 复制代码
  copyButton.addEventListener("click", () => {
    const code = codeContainer.textContent;
    try {
      // 使用clipboard API复制
      navigator.clipboard.writeText(code).then(() => {
        statusDiv.textContent = "代码已复制到剪贴板";
        setTimeout(() => {
          if (statusDiv.textContent === "代码已复制到剪贴板") {
            statusDiv.textContent = "";
          }
        }, 2000);
      });
    } catch (err) {
      statusDiv.textContent = "复制失败: " + err.message;
    }
  });
  
  return { statusDiv, diagramContainer, codeContainer, zoomControls };
}

// 添加缩放功能
function setupZoomControls(container, diagramContainer) {
  // 当前缩放级别
  let currentZoom = CONFIG.initialZoom;
  
  // 创建缩放控制器容器
  const zoomControls = container.createEl("div", { cls: "zoom-controls" });
  zoomControls.style.marginTop = "10px";
  zoomControls.style.marginBottom = "10px";
  zoomControls.style.display = "flex";
  zoomControls.style.alignItems = "center";
  
  // 创建缩放按钮
  const zoomOutBtn = zoomControls.createEl("button", { text: "➖" });
  const zoomResetBtn = zoomControls.createEl("button", { text: "重置" });
  const zoomInBtn = zoomControls.createEl("button", { text: "➕" });
  const zoomDisplay = zoomControls.createEl("span");
  
  // 样式设置
  zoomOutBtn.style.margin = "0 5px";
  zoomResetBtn.style.margin = "0 5px";
  zoomInBtn.style.margin = "0 5px";
  zoomDisplay.style.margin = "0 10px";
  zoomDisplay.style.minWidth = "60px";
  zoomDisplay.style.textAlign = "center";
  
  // 更新缩放显示
  function updateZoomDisplay() {
    zoomDisplay.textContent = `${Math.round(currentZoom * 100)}%`;
    
    // 更新图表容器样式
    const svgElement = diagramContainer.querySelector("svg");
    if (svgElement) {
      // 应用缩放变换
      svgElement.style.transform = `scale(${currentZoom})`;
      svgElement.style.transformOrigin = "top left";
      
      // 调整容器高度适应缩放
      diagramContainer.style.height = `${svgElement.getBBox().height * currentZoom + 40}px`;
    }
  }
  
  // 缩放函数
  function zoomIn() {
    currentZoom += CONFIG.zoomStep;
    updateZoomDisplay();
  }
  
  function zoomOut() {
    currentZoom = Math.max(0.1, currentZoom - CONFIG.zoomStep);
    updateZoomDisplay();
  }
  
  function resetZoom() {
    currentZoom = CONFIG.initialZoom;
    updateZoomDisplay();
  }
  
  // 绑定按钮事件
  zoomInBtn.addEventListener("click", zoomIn);
  zoomOutBtn.addEventListener("click", zoomOut);
  zoomResetBtn.addEventListener("click", resetZoom);
  
  // 添加鼠标滚轮缩放支持
  diagramContainer.addEventListener("wheel", (event) => {
    // 只有按下Ctrl键才缩放
    if (event.ctrlKey) {
      event.preventDefault();
      
      if (event.deltaY < 0) {
        zoomIn();
      } else {
        zoomOut();
      }
    }
  });
  
  // 添加拖拽平移支持
  let isDragging = false;
  let lastX = 0;
  let lastY = 0;
  
  diagramContainer.addEventListener("mousedown", (event) => {
    // 中键或左键+Alt键开始拖拽
    if (event.button === 1 || (event.button === 0 && event.altKey)) {
      isDragging = true;
      lastX = event.clientX;
      lastY = event.clientY;
      diagramContainer.style.cursor = "grabbing";
      event.preventDefault();
    }
  });
  
  
  container.addEventListener("mousemove", (event) => {
    if (isDragging) {
      const svgElement = diagramContainer.querySelector("svg");
      if (svgElement) {
        // 计算移动距离
        const dx = event.clientX - lastX;
        const dy = event.clientY - lastY;
        
        // 获取当前滚动位置
        const currentScrollLeft = diagramContainer.scrollLeft;
        const currentScrollTop = diagramContainer.scrollTop;
        
        // 更新滚动位置
        diagramContainer.scrollLeft = currentScrollLeft - dx;
        diagramContainer.scrollTop = currentScrollTop - dy;
        
        // 更新最后位置
        lastX = event.clientX;
        lastY = event.clientY;
      }
    }
  });
  
  container.addEventListener("mouseup", () => {
    if (isDragging) {
      isDragging = false;
      diagramContainer.style.cursor = "";
    }
  });
  
  container.addEventListener("mouseleave", () => {
    if (isDragging) {
      isDragging = false;
      diagramContainer.style.cursor = "";
    }
  });
  
  // 设置初始缩放级别
  updateZoomDisplay();
  
  // 添加一个帮助提示
  const helpText = zoomControls.createEl("span", { text: "(提示: Ctrl+滚轮缩放, Alt+拖拽移动)" });
  helpText.style.fontSize = "0.8em";
  helpText.style.color = "#666";
  helpText.style.marginLeft = "15px";
  
  return { zoomIn, zoomOut, resetZoom, updateZoomDisplay };
}

// 渲染图表
async function renderDiagram(container, statusDiv, diagramContainer, codeContainer, zoomControls) {
  statusDiv.textContent = "正在加载文件...";
  
  try {
    // 获取所有文件
    const files = getFiles();
    
    if (files.length === 0) {
      statusDiv.textContent = "未找到符合条件的文件";
      return;
    }
    
    statusDiv.textContent = `找到 ${files.length} 个文件，正在分析...`;
    
  // ...
// 解析节点
const nodes = files.map(file => {
  const fileInfo = parseFileInfo(file.file.name);
  return {
    id: fileInfo.id,
    name: fileInfo.name,
    hasStateTransition: fileInfo.hasStateTransition,
    baseState: fileInfo.baseState,
    fileName: file.file.name,
    path: file.file.path,
    mermaidViewComplete: file.mermaidViewComplete, // 这是我们上次加的
    mermaidViewHighlight: file.mermaidViewHighlight // <<< 增加这一行，传递重点状态
  };
});
// ...


    
    // 计算所有节点的父节点ID
    nodes.forEach(node => {
      node.parentId = getParentId(node.id);
    });
    
    // 查找目标节点
    const targetNode = nodes.find(node => node.id === CONFIG.targetNode);
    
    if (!targetNode) {
      statusDiv.textContent = `错误: 找不到节点 "${CONFIG.targetNode}"`;
      diagramContainer.innerHTML = `<div style="color:red;padding:10px;">目标节点未找到，请检查节点ID是否正确</div>`;
      return;
    }
    
    // 构建关系图
    statusDiv.textContent = "正在构建状态转移关系图...";
    const graph = buildStateTransitionGraph(targetNode, nodes, CONFIG.maxDepth);
    
    // ===== 添加节点点击回调函数 =====
    const handleNodeClick = function(nodeId) {
      // 从全局映射中获取原始节点数据
      if (window.stateTransitionNodeIdMap && window.stateTransitionNodeIdMap[nodeId]) {
        const node = window.stateTransitionNodeIdMap[nodeId];
        
        // 如果节点有文件名，滚动到对应笔记
        if (node.fileName) {
          console.log(`点击了节点: ${nodeId} -> 文件: ${node.fileName}`);
          findAndScrollToFileInAOTM(node.fileName);
        } else {
          showToast(`节点 ${node.name || nodeId} 没有关联的文件`, "info");
        }
      } else {
        showToast(`未找到节点 ${nodeId} 的相关信息`, "error");
        console.warn(`未找到节点 ${nodeId} 的映射信息`);
      }
    };
    
    // 生成Mermaid代码 - 传入点击回调
    statusDiv.textContent = "正在生成图表...";
    const mermaidCode = generateMermaidCode(graph, handleNodeClick);
    
    // 显示代码
    codeContainer.textContent = mermaidCode;
    
    // 创建Mermaid图表
    diagramContainer.innerHTML = `<div class="mermaid">${mermaidCode}</div>`;
    
    
    // 渲染图表
    if (window.mermaid) {
      window.mermaid.initialize({ 
        startOnLoad: false,
        theme: 'default',
        securityLevel: 'loose', // 添加这一行
        flowchart: {
          useMaxWidth: true,
          htmlLabels: true,
          curve: 'basis'
        }
      });
      
      await window.mermaid.init(undefined, diagramContainer.querySelector('.mermaid'));
      statusDiv.textContent = `图表已生成，显示 ${graph.nodes.length} 个节点，${graph.subgraphs.length} 个子图（可点击节点导航到对应笔记）`;
      
      // 渲染完成后，如果启用了缩放功能，更新缩放控制
      if (CONFIG.enableZoom && zoomControls) {
        zoomControls.updateZoomDisplay();
      }
    } else {
      statusDiv.textContent = "错误: Mermaid库未加载";
    }
    
  } catch (error) {
    statusDiv.textContent = `错误: ${error.message}`;
    if (CONFIG.debug) {
      diagramContainer.innerHTML += `<pre style="color:red;padding:10px;overflow:auto">${error.stack}</pre>`;
    }
  }
}

// ===== 主程序入口 =====
// 创建UI并渲染初始图表
const ui = createUI(dv.container);
renderDiagram(dv.container, ui.statusDiv, ui.diagramContainer, ui.codeContainer, ui.zoomControls);
```