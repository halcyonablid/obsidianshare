---
qishiriqidate: 2025-03-18
qishiriqitime: 17:42:33
atomle: true
antinet: atom
索引关键词已录入: true
树的结构: true
---

```dataviewjs
// --- STATE MANAGEMENT (SESSION-PERSISTENT & UNIQUE) ---
// Use a unique suffix "_newera" to avoid conflicts.
if (!window.myTreeViewFoldState_newera) {
    window.myTreeViewFoldState_newera = new Set();
}
const foldedNodes = window.myTreeViewFoldState_newera;

if (!window.myTreeViewDisplayState_newera) {
    window.myTreeViewDisplayState_newera = {
        maxLevel: 20,
        highlightLevel: 0,
        highlightSubLevels: false,
        currentHighlightedFile: null,
    };
}
const viewState = window.myTreeViewDisplayState_newera;

// --- SCRIPT-LOCAL VARIABLES ---
let parentHierarchyCodes = new Set();
const startFromLevel = 0; // Key difference: Starts from level 5
let maxExistingLevel = 0;

// --- INITIALIZATION ---
const pages = dv.pages()
    .where(p => p["树的结构"] === true)
    .sort(p => p.file.name);

// --- HELPER FUNCTIONS ---
function getHierarchyCode(fileName) {
    const atIndex = fileName.indexOf('@');
    if (atIndex === -1) return null;
    const dashIndex = fileName.indexOf('-', atIndex);
    if (dashIndex === -1) return null;
    return fileName.substring(atIndex + 1, dashIndex).trim();
}

function precomputeParentNodes() {
    const allCodes = new Set(pages.map(p => getHierarchyCode(p.file.name)).filter(Boolean));
    parentHierarchyCodes.clear();
    allCodes.forEach(code => {
        const hasChildren = Array.from(allCodes).some(otherCode => otherCode.startsWith(code + '.') && otherCode !== code);
        if (hasChildren) {
            parentHierarchyCodes.add(code);
        }
    });
}

function toggleFold(hierarchyCode) {
    if (foldedNodes.has(hierarchyCode)) foldedNodes.delete(hierarchyCode);
    else foldedNodes.add(hierarchyCode);
    renderTree();
}

function unfoldAncestors(hierarchyCode) {
    if (!hierarchyCode) return;
    const parts = hierarchyCode.split('.');
    for (let i = 1; i < parts.length; i++) {
        const ancestorCode = parts.slice(0, i).join('.');
        if (foldedNodes.has(ancestorCode)) foldedNodes.delete(ancestorCode);
    }
}

function isAncestorFolded(hierarchyCode) {
    if (!hierarchyCode) return false;
    const parts = hierarchyCode.split('.');
    for (let i = 1; i < parts.length; i++) {
        const ancestorCode = parts.slice(0, i).join('.');
        if (foldedNodes.has(ancestorCode)) return true;
    }
    return false;
}

function processKeywords(text) {
    const regex = /··([^·]+)··/g;
    if (!text.includes('··')) return document.createTextNode(text);
    const fragment = document.createDocumentFragment();
    let lastIndex = 0; let match;
    while ((match = regex.exec(text)) !== null) {
        if (match.index > lastIndex) fragment.appendChild(document.createTextNode(text.substring(lastIndex, match.index)));
        let keyword = match[1];
        if (/[A-Z]/.test(keyword.charAt(0))) keyword = keyword.substring(1);
        const keywordSpan = document.createElement('span');
        keywordSpan.textContent = keyword;
        keywordSpan.className = 'keyword-highlight';
        fragment.appendChild(keywordSpan);
        lastIndex = match.index + match[0].length;
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
    return fragment;
}

// --- INTERACTION FUNCTIONS ---
function findAndScrollToFileInAOTM(fileName) {
    setTimeout(() => {
        try {
            const aotmViews = document.querySelectorAll('.custom-table tbody');
            if (!aotmViews.length) return;
            let targetRow = null;
            for (const tableBody of aotmViews) {
                const link = Array.from(tableBody.querySelectorAll('.filename-column a')).find(a => a.textContent === fileName);
                if (link) { targetRow = link.closest('tr'); break; }
            }
            if (!targetRow) return;

            // --- MODIFICATION START ---
            // 使用 getComputedStyle 获取元素实际的背景色，无论它是通过内联样式还是CSS类设置的
            const originalColor = window.getComputedStyle(targetRow).backgroundColor;
            // --- MODIFICATION END ---

            const scrollContainer = targetRow.closest('.view-content');
            if (!scrollContainer) return;

            targetRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
            targetRow.style.transition = 'background-color 0.8s';
            targetRow.style.backgroundColor = 'rgba(255, 255, 0, 0.3)'; // 设置为黄色高亮

            // --- MODIFICATION START ---
            // 3秒后恢复保存的原始背景色
            setTimeout(() => {
                targetRow.style.backgroundColor = originalColor;
            }, 3000);
            // --- MODIFICATION END ---

        } catch (error) { console.error('滚动定位错误:', error); }
    }, 200);
}

function findCenterNoteInSidebar() {
    try {
        const aotmViews = document.querySelectorAll('.workspace-leaf:not(.mod-active) .custom-table tbody');
        if (!aotmViews.length) return null;
        const tableBody = aotmViews[0];
        const scrollContainer = tableBody.closest('.view-content');
        if (!scrollContainer) return null;
        const containerRect = scrollContainer.getBoundingClientRect();
        const containerCenter = containerRect.top + containerRect.height / 2;
        const allRows = Array.from(tableBody.querySelectorAll('tr'));
        let closestRow = allRows.reduce((closest, row) => {
            const rowRect = row.getBoundingClientRect();
            const rowCenter = rowRect.top + rowRect.height / 2;
            const distance = Math.abs(rowCenter - containerCenter);
            return distance < closest.minDistance ? { minDistance: distance, row: row } : closest;
        }, { minDistance: Infinity, row: null }).row;
        if (!closestRow) return null;
        const filenameElement = closestRow.querySelector('.filename-column a');
        return filenameElement ? filenameElement.textContent : null;
    } catch (error) { console.error('查找中心笔记错误:', error); return null; }
}

// --- UI and RENDER ---
dv.el("h3", "层级结构视图（大纲模式 - newera）");
dv.el("div", "<b>交互:</b> [单击]滚动右侧视图, [右键]高亮同级, [▶/▼]折叠/展开<br><b>快捷键:</b> [J/K]增减层级, [N/M]高亮层级, [H]定位高亮", {cls: "tree-control-info"});
const levelInfo = dv.el("div", "", {cls: "tree-level-info"});
const container = dv.el("div", "", {cls: "hierarchical-tree-structure"});

pages.forEach(page => {
    const code = getHierarchyCode(page.file.name);
    if (code) {
        const effectiveLevels = Math.max(0, code.split('.').length - (startFromLevel - 1));
        maxExistingLevel = Math.max(maxExistingLevel, effectiveLevels);
    }
});

function getCurrentMaxVisibleLevel() { return Math.min(viewState.maxLevel, maxExistingLevel); }

function renderTree() {
    container.innerHTML = "";
    const currentMaxVisibleLevel = getCurrentMaxVisibleLevel();
    let levelInfoText = `当前显示层级: ${currentMaxVisibleLevel}/${maxExistingLevel}`;
    if (viewState.highlightLevel > 0) levelInfoText += ` | 高亮层级: ${viewState.highlightLevel}${viewState.highlightSubLevels ? " (含下级)" : ""}`;
    if (viewState.currentHighlightedFile) levelInfoText += ` | 定位高亮: ${viewState.currentHighlightedFile}`;
    levelInfo.innerHTML = levelInfoText;

    pages.forEach(page => {
        const fileName = page.file.name;
        const hierarchyCode = getHierarchyCode(fileName);
        
        let levelDepth = 0;
        if (hierarchyCode) {
            const levels = hierarchyCode.split('.');
            levelDepth = Math.max(0, levels.length - (startFromLevel - 1));
        }

        if (hierarchyCode && levelDepth === 0) return;
        if (levelDepth > viewState.maxLevel || isAncestorFolded(hierarchyCode)) return;

        const fileItemDiv = document.createElement("div");
        fileItemDiv.className = "tree-item tree-item-link";
        fileItemDiv.dataset.filename = fileName;
        fileItemDiv.dataset.level = levelDepth;

        const displayLevel = levelDepth > 0 ? levelDepth : 1;
        if (viewState.highlightLevel > 0) {
            if (viewState.highlightLevel === displayLevel) fileItemDiv.classList.add("tree-item-highlighted");
            else if (viewState.highlightSubLevels && displayLevel > viewState.highlightLevel) fileItemDiv.classList.add("tree-item-subhighlighted");
        }
        if (fileName === viewState.currentHighlightedFile) fileItemDiv.classList.add("tree-item-h-highlighted");

        const foldControl = document.createElement('span');
        const isParent = parentHierarchyCodes.has(hierarchyCode);
        if (isParent) {
            foldControl.className = 'fold-button';
            foldControl.textContent = foldedNodes.has(hierarchyCode) ? '▶' : '▼';
            foldControl.onclick = (e) => { e.stopPropagation(); toggleFold(hierarchyCode); };
        } else {
            foldControl.className = 'fold-placeholder';
            foldControl.innerHTML = '&nbsp;';
        }
        fileItemDiv.appendChild(foldControl);
        
        let prefix = "";
        for (let i = 1; i < levelDepth; i++) { prefix += "│ "; }
        if (levelDepth > 1) { prefix = prefix.substring(0, prefix.length - 2) + "├─ "; }
        else if (levelDepth === 1) { prefix = "● "; }
        else { prefix = "● "; }
        const prefixSpan = document.createElement('span');
        prefixSpan.className = 'tree-prefix';
        prefixSpan.textContent = prefix;
        fileItemDiv.appendChild(prefixSpan);

        fileItemDiv.appendChild(processKeywords(fileName));

        fileItemDiv.addEventListener("click", (e) => { e.preventDefault(); findAndScrollToFileInAOTM(fileName); });
        fileItemDiv.addEventListener("contextmenu", (e) => { 
            e.preventDefault(); 
            viewState.highlightLevel = displayLevel;
            viewState.highlightSubLevels = true; 
            renderTree(); 
        });

        container.appendChild(fileItemDiv);
    });

    if (viewState.currentHighlightedFile) {
        setTimeout(() => {
            const highlightedItem = container.querySelector('.tree-item-h-highlighted');
            if (highlightedItem) {
                highlightedItem.scrollIntoView({ behavior: 'smooth', block: 'center' });
                highlightedItem.classList.add('pulse-animation');
                setTimeout(() => highlightedItem.classList.remove('pulse-animation'), 2000);
            }
        }, 100);
    }
}

// --- GLOBAL KEYBOARD LISTENER (UNIQUE) ---
if (window.myTreeViewKeydownHandler_newera) {
    document.removeEventListener('keydown', window.myTreeViewKeydownHandler_newera);
}

window.myTreeViewKeydownHandler_newera = (e) => {
    let updated = false;
    const currentMaxVisibleLevel = getCurrentMaxVisibleLevel();
    const key = e.key.toLowerCase();

    if (key === 'k') {
        viewState.maxLevel = Math.min(viewState.maxLevel + 1, maxExistingLevel);
        updated = true;
    }
    if (key === 'j') {
        viewState.maxLevel = Math.max(1, viewState.maxLevel - 1);
        if (viewState.highlightLevel > viewState.maxLevel) viewState.highlightLevel = viewState.maxLevel;
        updated = true;
    }
    if (key === 'n') {
        viewState.highlightLevel = Math.max(0, viewState.highlightLevel - 1);
        viewState.highlightSubLevels = false;
        updated = true;
    }
    if (key === 'm') {
        if (viewState.highlightLevel < currentMaxVisibleLevel) viewState.highlightLevel += 1;
        viewState.highlightSubLevels = false;
        updated = true;
    }
    if (key === 'h') {
        const centerFile = findCenterNoteInSidebar();
        if (centerFile) {
            const targetPage = pages.find(p => p.file.name === centerFile);
            if (targetPage) unfoldAncestors(getHierarchyCode(targetPage.file.name));
            viewState.currentHighlightedFile = (viewState.currentHighlightedFile === centerFile) ? null : centerFile;
            updated = true;
        }
    }
    
    if (updated) renderTree();
};

document.addEventListener('keydown', window.myTreeViewKeydownHandler_newera);

// --- STYLES (No changes needed) ---
const styleEl = document.createElement("style");
styleEl.textContent = `
.hierarchical-tree-structure { font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace !important; white-space: nowrap; overflow-x: auto; padding: 10px 0; line-height: 1.6; font-size: 14px; }
.tree-item { display: flex; align-items: center; margin-bottom: 6px; padding: 3px 5px; border-radius: 3px; }
.tree-item-link { cursor: pointer; transition: background-color 0.15s ease; }
.tree-item-link:hover { background-color: var(--background-secondary); }
.fold-button, .fold-placeholder { display: inline-block; width: 1.5em; text-align: center; flex-shrink: 0; user-select: none; }
.fold-button { cursor: pointer; color: var(--text-accent); font-weight: bold; }
.fold-button:hover { color: var(--text-accent-hover); }
.tree-prefix { color: var(--text-faint); white-space: pre; }
.tree-item-highlighted { background-color: rgba(255, 165, 0, 0.3); font-weight: bold; }
.tree-item-subhighlighted { background-color: rgba(255, 165, 0, 0.1); }
.tree-item-h-highlighted { background-color: rgba(75, 192, 192, 0.3); font-weight: bold; border-left: 3px solid rgba(75, 192, 192, 0.8); }
@keyframes pulse-highlight { 0% { box-shadow: 0 0 0 0 rgba(75, 192, 192, 0.7); } 70% { box-shadow: 0 0 0 10px rgba(75, 192, 192, 0); } 100% { box-shadow: 0 0 0 0 rgba(75, 192, 192, 0); } }
.pulse-animation { animation: pulse-highlight 1.5s ease-out; }
.keyword-highlight { color: #e74c3c; font-weight: bold; }
.tree-control-info { margin-bottom: 8px; font-style: italic; color: var(--text-muted); font-size: 13px; line-height: 1.4; }
.tree-level-info { margin-bottom: 15px; font-weight: bold; color: var(--text-accent); font-size: 14px; }
`;
document.head.appendChild(styleEl);

// --- INITIAL RENDER ---
precomputeParentNodes();
renderTree();

```

·
·
·
·
·


·
·
·
·
·

·
·
·
·

·
·

·
·

·
·
·

·
·

·
·
·

·
```dataviewjs
// 获取所有树的结构=true的文件
const pages = dv.pages()
  .where(p => p["树的结构"] === true)
  .sort(p => p.file.name);

// 创建容器和标题
dv.el("h3", "层级结构视图");
dv.el("div", "按 [K] 键增加层级显示，按 [J] 键减少层级显示，点击节点前的图标可展开/折叠局部层级", {cls: "tree-control-info"});
const levelInfo = dv.el("div", "", {cls: "tree-level-info"});
const container = dv.el("div", "", {cls: "hierarchical-tree-structure"});

// 状态管理
let maxLevel = 10; // 默认显示所有层级
let maxExistingLevel = 0; // 存储实际存在的最大层级
let expandedNodes = new Set(); // 存储已展开的节点路径

// 分析所有文件，找出最大层级
pages.forEach(page => {
  if (!page || !page.file || !page.file.name) return;
  
  const fileName = page.file.name;
  const atIndex = fileName.indexOf('@');
  if (atIndex !== -1) {
    const dashIndex = fileName.indexOf('-', atIndex);
    if (dashIndex !== -1) {
      const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
      const levels = hierarchyCode.split('.');
      maxExistingLevel = Math.max(maxExistingLevel, levels.length);
    }
  }
});

// 查找AOTM视图并滚动到对应文件的函数
function findAndScrollToFileInAOTM(fileName) {
  // 延迟执行，确保DOM已经完全加载
  setTimeout(() => {
    try {
      // 查找右侧边栏中的AOTM视图（假设AOTM视图有一个自定义表格）
      const aotmViews = document.querySelectorAll('.custom-table tbody');
      
      if (!aotmViews || aotmViews.length === 0) {
        throw new Error('未找到AOTM视图或自定义表格');
      }
      
      // 尝试在每个找到的表格中查找目标行
      let targetRow = null;
      let containingTable = null;
      
      for (const tableBody of aotmViews) {
        const allRows = Array.from(tableBody.querySelectorAll('tr'));
        const foundRow = allRows.find(row => {
          // 尝试查找包含此文件名的链接或文本
          const link = row.querySelector('.filename-column a');
          return link && link.textContent === fileName;
        });
        
        if (foundRow) {
          targetRow = foundRow;
          containingTable = tableBody;
          break;
        }
      }
      
      if (!targetRow) {
        // 回退方案：查找包含此文件名的任何元素
        const allElements = document.querySelectorAll('.workspace-leaf:not(.mod-active) .view-content *');
        for (const element of allElements) {
          if (element.textContent.includes(fileName)) {
            targetRow = element.closest('tr') || element;
            break;
          }
        }
      }
      
      if (!targetRow) {
        new Notice(`在AOTM视图中未找到笔记: ${fileName}`);
        return;
      }
      
      // 查找包含目标行的滚动容器
      const scrollContainer = targetRow.closest('.workspace-leaf-content') || 
                              targetRow.closest('.view-content') || 
                              document.querySelector('.workspace-split.mod-vertical.mod-root');
      
      if (!scrollContainer) {
        throw new Error('未找到可滚动容器');
      }
      
      // 执行滚动，使目标行居中
      targetRow.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center'
      });
      
      // 添加视觉效果：暂时高亮目标行
      const originalBackground = targetRow.style.backgroundColor;
      targetRow.style.transition = 'background-color 0.8s';
      targetRow.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';  // 黄色高亮
      
      // 3秒后恢复原来的背景色
      setTimeout(() => {
        targetRow.style.backgroundColor = originalBackground;
      }, 3000);
      
      // 显示通知
      if (containingTable) {
        const allRows = Array.from(containingTable.querySelectorAll('tr'));
        const rowIndex = allRows.indexOf(targetRow) + 1;
        new Notice(`已找到并滚动到笔记：${fileName}（第 ${rowIndex} 行 / 共 ${allRows.length} 行）`);
      } else {
        new Notice(`已找到并滚动到笔记：${fileName}`);
      }
      
    } catch (error) {
      console.error('滚动定位错误:', error);
      new Notice(`查找或滚动过程中发生错误：${error.message}`);
    }
  }, 300); // 给DOM加载留出足够时间
}

// 检查节点是否有子节点
function hasChildren(nodePath) {
  if (!nodePath) return false;
  
  // 检查是否有任何文件路径以此为前缀
  for (const page of pages) {
    if (!page || !page.file || !page.file.name) continue;
    
    const fileName = page.file.name;
    const atIndex = fileName.indexOf('@');
    if (atIndex !== -1) {
      const dashIndex = fileName.indexOf('-', atIndex);
      if (dashIndex !== -1) {
        const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
        // 如果找到一个以此为前缀的节点，且比它长，则是子节点
        if (hierarchyCode.startsWith(nodePath + '.') && hierarchyCode !== nodePath) {
          return true;
        }
      }
    }
  }
  return false;
}

// 获取节点的直接子节点
function getDirectChildren(nodePath) {
  const children = [];
  if (!nodePath) return children;
  
  const prefix = nodePath ? nodePath + '.' : '';
  const prefixLength = prefix.length;
  
  // 查找所有前缀匹配的路径
  for (const page of pages) {
    if (!page || !page.file || !page.file.name) continue;
    
    const fileName = page.file.name;
    const atIndex = fileName.indexOf('@');
    if (atIndex !== -1) {
      const dashIndex = fileName.indexOf('-', atIndex);
      if (dashIndex !== -1) {
        const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
        
        // 检查是否是直接子节点
        if (hierarchyCode.startsWith(prefix) && hierarchyCode !== nodePath) {
          // 提取层级后面的部分，确保只是直接子节点
          const remaining = hierarchyCode.substring(prefixLength);
          if (!remaining.includes('.')) {
            children.push({
              path: hierarchyCode,
              page: page
            });
          }
        }
      }
    }
  }
  
  return children;
}

// 切换节点展开状态
function toggleNodeExpansion(nodePath) {
  if (!nodePath) return;
  
  if (expandedNodes.has(nodePath)) {
    // 如果已展开，则收起
    expandedNodes.delete(nodePath);
    
    // 同时删除所有以此为前缀的路径（子节点）
    for (const path of Array.from(expandedNodes)) {
      if (path.startsWith(nodePath + '.')) {
        expandedNodes.delete(path);
      }
    }
  } else {
    // 如果未展开，则展开
    expandedNodes.add(nodePath);
  }
  
  // 重新渲染
  renderTree();
}

// 渲染树结构的函数
function renderTree() {
  // 清空容器
  container.innerHTML = "";
  
  // 更新层级信息显示
  levelInfo.innerText = `当前显示层级: ${Math.min(maxLevel, maxExistingLevel)} / ${maxExistingLevel}`;
  
  // 根节点（没有@的文件）
  const rootNodes = pages.filter(p => p && p.file && p.file.name && !p.file.name.includes('@'));
  if (rootNodes.length > 0) {
    rootNodes.forEach(page => {
      const fileItemDiv = document.createElement("div");
      fileItemDiv.className = "tree-item tree-item-link";
      fileItemDiv.textContent = `● ${page.file.name}`;
      fileItemDiv.addEventListener("click", (e) => {
        e.preventDefault();
        findAndScrollToFileInAOTM(page.file.name);
      });
      container.appendChild(fileItemDiv);
    });
  }
  
  // 创建一个映射，通过路径快速查找页面
  const pathToPageMap = new Map();
  pages.forEach(page => {
    if (!page || !page.file || !page.file.name) return;
    
    const fileName = page.file.name;
    const atIndex = fileName.indexOf('@');
    if (atIndex !== -1) {
      const dashIndex = fileName.indexOf('-', atIndex);
      if (dashIndex !== -1) {
        const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
        pathToPageMap.set(hierarchyCode, page);
      }
    }
  });
  
  // 递归渲染节点及其子节点
  function renderNode(nodePath, depth, prefix = "") {
    // 如果深度超过最大显示深度，不显示
    if (depth > maxLevel) return;
    
    const page = pathToPageMap.get(nodePath);
    if (!page || !page.file || !page.file.name) return;
    
    const fileName = page.file.name;
    const hasChildNodes = hasChildren(nodePath);
    
    // 创建节点内容
    const nodeContent = document.createElement("div");
    nodeContent.className = "tree-item tree-item-link";
    
    // 创建展开/折叠图标
    let expandIcon = "";
    if (hasChildNodes) {
      expandIcon = expandedNodes.has(nodePath) ? "▼ " : "► ";
    } else {
      expandIcon = "● ";
    }
    
    // 设置节点前缀和内容
    const displayPrefix = prefix + expandIcon;
    nodeContent.textContent = displayPrefix + fileName;
    nodeContent.dataset.filename = fileName;
    nodeContent.dataset.path = nodePath;
    
    // 点击事件：文本区域点击导航到文件
    nodeContent.addEventListener("click", (e) => {
      // 检查点击是否在展开/折叠图标上
      const text = nodeContent.textContent;
      const iconEndPos = displayPrefix.length;
      const clickPos = getClickPosition(e, nodeContent);
      
      if (clickPos < iconEndPos && hasChildNodes) {
        // 点击在图标上，切换展开/折叠状态
        e.preventDefault();
        e.stopPropagation();
        toggleNodeExpansion(nodePath);
      } else {
        // 点击在文本上，滚动到文件
        e.preventDefault();
        findAndScrollToFileInAOTM(fileName);
      }
    });
    
    // 将节点添加到容器
    container.appendChild(nodeContent);
    
    // 如果节点已展开，渲染其子节点
    if (expandedNodes.has(nodePath)) {
      const children = getDirectChildren(nodePath);
      children.forEach(child => {
        // 为子节点计算新的前缀
        const childPrefix = prefix + "    ";
        renderNode(child.path, depth + 1, childPrefix);
      });
    }
  }
  
  // 辅助函数：获取点击在元素中的水平位置
  function getClickPosition(event, element) {
    const rect = element.getBoundingClientRect();
    return event.clientX - rect.left;
  }
  
  // 渲染顶级节点
  const topLevelNodes = pages.filter(p => {
    if (!p || !p.file || !p.file.name) return false;
    
    const fileName = p.file.name;
    const atIndex = fileName.indexOf('@');
    if (atIndex !== -1) {
      const dashIndex = fileName.indexOf('-', atIndex);
      if (dashIndex !== -1) {
        const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
        return !hierarchyCode.includes('.');
      }
    }
    return false;
  });
  
  // 安全地排序顶级节点
  if (topLevelNodes && topLevelNodes.length > 0) {
    topLevelNodes.sort((a, b) => {
      if (!a || !a.file || !a.file.name) return -1;
      if (!b || !b.file || !b.file.name) return 1;
      
      const fileNameA = a.file.name;
      const fileNameB = b.file.name;
      
      const atIndexA = fileNameA.indexOf('@');
      const atIndexB = fileNameB.indexOf('@');
      
      if (atIndexA === -1) return -1;
      if (atIndexB === -1) return 1;
      
      const dashIndexA = fileNameA.indexOf('-', atIndexA);
      const dashIndexB = fileNameB.indexOf('-', atIndexB);
      
      if (dashIndexA === -1) return -1;
      if (dashIndexB === -1) return 1;
      
      const codeA = fileNameA.substring(atIndexA + 1, dashIndexA).trim();
      const codeB = fileNameB.substring(atIndexB + 1, dashIndexB).trim();
      
      return codeA.localeCompare(codeB, undefined, {numeric: true, sensitivity: 'base'});
    });
  }
  
  // 渲染每个顶级节点
  if (topLevelNodes && topLevelNodes.length > 0) {
    topLevelNodes.forEach(page => {
      if (!page || !page.file || !page.file.name) return;
      
      const fileName = page.file.name;
      const atIndex = fileName.indexOf('@');
      if (atIndex !== -1) {
        const dashIndex = fileName.indexOf('-', atIndex);
        if (dashIndex !== -1) {
          const hierarchyCode = fileName.substring(atIndex + 1, dashIndex).trim();
          renderNode(hierarchyCode, 1);
        }
      }
    });
  }
}

// 添加双击事件来实现文件跳转（保留原有功能作为备选）
container.addEventListener("dblclick", (e) => {
  const fileItem = e.target.closest('.tree-item-link');
  if (fileItem) {
    const fileName = fileItem.dataset.filename;
    if (fileName) {
      // 查找对应的页面对象
      const page = pages.find(p => p && p.file && p.file.name === fileName);
      if (page) {
        app.workspace.openLinkText(page.file.path, "");
      }
    }
  }
});

// 添加键盘事件监听
document.addEventListener('keydown', (e) => {
  let updated = false;
  
  // 增加层级显示 (K键)
  if (e.key === 'k' || e.key === 'K') {
    maxLevel = Math.min(maxLevel + 1, maxExistingLevel);
    updated = true;
  }
  
  // 减少层级显示 (J键)
  if (e.key === 'j' || e.key === 'J') {
    maxLevel = Math.max(1, maxLevel - 1);
    updated = true;
  }
  
  // 如果有更新，重新渲染树
  if (updated) {
    renderTree();
  }
});

// 添加样式
const styleEl = document.createElement("style");
styleEl.textContent = `
  .hierarchical-tree-structure {
    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace !important;
    white-space: nowrap;
    overflow-x: auto;
    padding: 10px 0;
    line-height: 1.5;
    letter-spacing: normal;
    font-size: 14px;
  }
  
  .tree-item {
    margin-bottom: 6px;
    color: var(--text-normal);
    padding: 3px 5px;
    border-radius: 3px;
    font-weight: normal;
    word-spacing: normal;
    display: block;
  }
  
  .tree-item-link {
    cursor: pointer;
    transition: background-color 0.15s ease;
  }
  
  .tree-item-link:hover {
    background-color: var(--background-secondary);
  }
  
  .tree-control-info {
    margin-bottom: 8px;
    font-style: italic;
    color: var(--text-muted);
    font-size: 13px;
  }
  
  .tree-level-info {
    margin-bottom: 15px;
    font-weight: bold;
    color: var(--text-accent);
    font-size: 14px;
  }
`;
document.head.appendChild(styleEl);

// 初始渲染
renderTree();
```


![[ATOM@006- 针对树进行构成的方法，使用excalidraw 2025-03-18 17.42.36.excalidraw]]


·
·