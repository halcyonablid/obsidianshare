parent::[[ATOM- 原子化行动提示]]

# 在这里是排序以及视图
## 排序 
qishiriqi&atomle
```dataviewjs
// 定义颜色选项和颜色映射
const colorOptions = [
  "钴蓝", "翡翠绿", "奶油色", "米色", "褐灰色", "中棕色", "亮红色", "亮黄色", 
  "亮蓝色", "深紫色", "橙色", "绿色", "粉红色", "金色", "银色", "铜色", 
  "珊瑚红", "孔雀蓝", "薰衣草紫", "玫瑰金", "青铜色", "深绿色", "勃艮第红", 
  "蒂芙尼蓝", "杏色", "石榴红", "鸭蛋青", "芥末黄", "茄子紫", "橄榄绿", 
  "赭石色", "靛蓝"
];

const colorMap = {
  "钴蓝": ["🔵", "#0047AB"],
  "翡翠绿": ["🟢", "#50C878"],
  "奶油色": ["⚪", "#FFFDD0"],
  "米色": ["⚪", "#F5F5DC"],
  "褐灰色": ["⚫", "#8B8589"],
  "中棕色": ["🟤", "#A52A2A"],
  "亮红色": ["🔴", "#FF0000"],
  "亮黄色": ["🟡", "#FFFF00"],
  "亮蓝色": ["🔵", "#0000FF"],
  "深紫色": ["🟣", "#4B0082"],
  "橙色": ["🟠", "#FFA500"],
  "绿色": ["🟢", "#008000"],
  "粉红色": ["🟣", "#FFC0CB"],
  "金色": ["🟡", "#FFD700"],
  "银色": ["⚪", "#C0C0C0"],
  "铜色": ["🟤", "#B87333"],
  "珊瑚红": ["🔴", "#FF7F50"],
  "孔雀蓝": ["🔵", "#33A1C9"],
  "薰衣草紫": ["🟣", "#E6E6FA"],
  "玫瑰金": ["🟣", "#B76E79"],
  "青铜色": ["🟤", "#CD7F32"],
  "深绿色": ["🟢", "#228B22"],
  "勃艮第红": ["🔴", "#800020"],
  "蒂芙尼蓝": ["🔵", "#0ABAB5"],
  "杏色": ["🟠", "#FBCEB1"],
  "石榴红": ["🔴", "#C41E3A"],
  "鸭蛋青": ["🔵", "#E0FFFF"],
  "芥末黄": ["🟡", "#FFDB58"],
  "茄子紫": ["🟣", "#614051"],
  "橄榄绿": ["🟢", "#808000"],
  "赭石色": ["🟤", "#A0522D"],
  "靛蓝": ["🔵", "#4B0082"]
};

// 创建基于日期的种子
function getDateSeed() {
    const now = new Date();
    return now.getFullYear() * 10000 + (now.getMonth() + 1) * 100 + now.getDate();
}

// 创建一个伪随机数生成器
function createPRNG(seed) {
  return function() {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
}

// 为每个场景分配随机颜色
function assignColorsToScenes(pages) {
    const sceneColors = {};
    const prng = createPRNG(getDateSeed());  // 使用基于日期的种子

    pages.forEach(page => {
        const scene = page.changjing || '未分类';
        if (!sceneColors[scene]) {
            const randomIndex = Math.floor(prng() * colorOptions.length);
            sceneColors[scene] = colorOptions[randomIndex];
        }
        page.color = sceneColors[scene];
    });
}

// 创建颜色选择下拉框的函数
function createColorSelect(page) {
    const select = document.createElement("select");
    select.innerHTML = `<option value="">选择颜色</option>` + 
        colorOptions.map(color => `<option value="${color}" ${page.color === color ? 'selected' : ''}>${colorMap[color][0]} ${color}</option>`).join("");
    
    select.addEventListener("change", async (event) => {
        const newColor = event.target.value;
        try {
            const file = app.vault.getAbstractFileByPath(page.file.path);
            if (file && file instanceof obsidian.TFile) {
                const fileContent = await app.vault.read(file);
                let updatedContent;
                
                const frontmatterRegex = /^---\n([\s\S]*?)\n---/;
                const frontmatterMatch = fileContent.match(frontmatterRegex);
                
                if (frontmatterMatch) {
                    let frontmatter = frontmatterMatch[1];
                    const colorRegex = /color:\s*(.*)/;
                    if (frontmatter.match(colorRegex)) {
                        frontmatter = frontmatter.replace(colorRegex, `color: ${newColor}`);
                    } else {
                        frontmatter += `\ncolor: ${newColor}`;
                    }
                    updatedContent = fileContent.replace(frontmatterRegex, `---\n${frontmatter}\n---`);
                } else {
                    updatedContent = `---\ncolor: ${newColor}\n---\n\n${fileContent}`;
                }
                
                await app.vault.modify(file, updatedContent);
                console.log(`Updated color to ${newColor} for ${page.file.name}`);
                
                setTimeout(() => {
                    dv.refresh();
                }, 100);
            } else {
                console.error(`File not found: ${page.file.path}`);
            }
        } catch (error) {
            console.error(`Error updating color for ${page.file.name}:`, error);
        }
    });

    return select;
}

// 计算密度的函数
function calculateDensity(page) {
    if (page.zhongyaochengdu && page.yujishiyongshijianxiaoshishu) {
        return page.zhongyaochengdu / page.yujishiyongshijianxiaoshishu;
    }
    return null;
}

// 获取所有符合条件的页面
let pages = dv.pages('"项目"')
    .where(p => p.qishiriqidate && p.atomle)
    .sort(p => {
        const density = calculateDensity(p);
        return density !== null ? -density : -Infinity;  // 使用负无穷大确保没有密度的排在最后
    });

// 为场景分配随机颜色
assignColorsToScenes(pages);

// 创建表格
dv.table(["笔记", "颜色选择", "颜色显示", "密度", "重要程度", "小时数", "场景"],
  pages.map(p => {
    const [emoji, hexColor] = p.color ? colorMap[p.color] || ["", ""] : ["", ""];
    const density = calculateDensity(p);
    return [
      dv.fileLink(p.file.path, false, p.file.name),
      createColorSelect(p),
      `<span style="background-color:${hexColor}; width:20px; height:20px; display:inline-block;"></span>`,
      density !== null ? density.toFixed(2) : "N/A",
      p.zhongyaochengdu || "N/A",
      p.yujishiyongshijianxiaoshishu || "N/A",
      p.changjing || "未分类"
    ];
  })
);



```

``` dataviewjs
// Get pages with "项目" tag and a duedate or qishiriqidate, sorted by date descending
let pages = dv.pages('"项目"')
  .where(p => (p.duedate || p.qishiriqidate) &&  p.atomle)
  .sort(p => new Date() - new Date(p.qishiriqidate), 'desc');  

// Get labels (file names) and data (days since duedate or qishiriqidate)
let labels = pages.map(p => p.file.name);
let duedateData = pages.map(p => p.duedate ? Math.floor((new Date(p.duedate) - new Date()) / (1000 * 60 * 60 * 24)) : null);
let qishiriqidateData = pages.map(p => p.qishiriqidate ? Math.floor((new Date() - new Date(p.qishiriqidate)) / (1000 * 60 * 60 * 24)) : null);

// Generate background colors based on qidianbu property
let backgroundColor = pages.map(p => p.qidianbu === true ? 'yellow' : 'rgba(54, 162, 235, 0.5)');

// Generate combined chart
dv.paragraph(`\`\`\`chart
type: bar
labels: [${labels.map(l => `"${l}"`).join(", ")}]
series:
- title: "Days Since duedate"
  data: [${duedateData.join(", ")}]
- title: "Days Since qishiriqidate"
  data: [${qishiriqidateData.join(", ")}]
backgroundColor: [${backgroundColor.map(c => `"${c}"`).join(", ")}]
width: 100%
height: 1000
\`\`\``);
```

## 截止日期 ,作为一个选择事项的重要依据

```dataview
TABLE 
 (date(duedate) - date(today)).days AS "DAY remain",duedate AS "截止"
FROM "项目"
WHERE qishiriqidate and atomle and duedate

SORT (date(duedate) - date(today)).days ASC
```
距离截止
```dataviewjs

// 获取包含 qishiriqidate 的页面 
let pages = dv.pages('"项目"') 
.where(p => p.duedate && p.atomle) 
.sort(p =>  new Date() - new Date(p.duedate) , 'desc'); 
// 获取标签和数据
let labels = pages.map(p => p.file.name); 
let data = pages.map(p => Math.floor((new Date(p.duedate) - new Date() + 1) / (1000 * 60 * 60 * 24))); 
// 生成背景颜色数组 
let backgroundColor = pages.map(p => p.qidianbu === true ? 'yellow' : 'rgba(54, 162, 235, 0.5)');
// 生成图表 
dv.paragraph(`\`\`\`chart 
type: bar 
labels: [${labels.map(l => `"${l}"`).join(", ")}] 
series: 
- title: "Days Since" 
- data: [${data.join(", ")}] 
- backgroundColor: [${backgroundColor.map(c => `"${c}"`).join(", ")}]
width: 100% 
height: 1000
\`\`\``);
```
## 场景
```dataviewjs
// 防抖函数
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// 获取所有符合条件的页面
let pages = dv.pages('"项目"')
  .where(p => p.qishiriqidate && p.atomle);

// 按场景分组页面并计算每个场景的事项数量
let groupedPages = {};
pages.forEach(page => {
  const changjing = page.changjing || '未分类';
  if (!groupedPages[changjing]) {
    groupedPages[changjing] = [];
  }
  groupedPages[changjing].push(page);
});

// 计算总事项数
const totalItems = pages.length;

// 局部更新函数
function updatePageInTable(page, newChangjing) {
  const tableRows = document.querySelectorAll('tr');
  for (let row of tableRows) {
    if (row.querySelector('a')?.getAttribute('href') === page.file.path) {
      row.querySelector('td:nth-child(2)').textContent = newChangjing;
      break;
    }
  }
}

// 创建场景输入框和更新按钮的函数
function createSceneInput(page) {
  const container = document.createElement('div');
  container.style.display = 'flex';
  container.style.alignItems = 'center';

  const input = document.createElement('input');
  input.type = 'text';
  input.value = page.changjing || '';
  input.style.width = '100px';
  input.style.marginRight = '5px';

  const button = document.createElement('button');
  button.textContent = '更新';
  button.onclick = async () => {
    const newValue = input.value.trim();
    if (newValue) {
      try {
        const file = app.vault.getAbstractFileByPath(page.file.path);
        if (file instanceof obsidian.TFile) {
          await app.fileManager.processFrontMatter(file, (frontmatter) => {
            frontmatter.changjing = newValue;
          });
          console.log(`Updated changjing to ${newValue} for ${page.file.name}`);
          // 局部更新
          updatePageInTable(page, newValue);
        } else {
          console.error(`File not found: ${page.file.path}`);
        }
      } catch (error) {
        console.error(`Error updating changjing for ${page.file.name}:`, error);
      }
    }
  };

  container.appendChild(input);
  container.appendChild(button);
  return container;
}

// 创建总结信息
let summaryInfo = `**总事项数: ${totalItems}**\n\n各场景事项数：\n`;
Object.keys(groupedPages).forEach(scene => {
  summaryInfo += `- ${scene}: ${groupedPages[scene].length}\n`;
});

// 显示总结信息
dv.paragraph(summaryInfo);

// 获取所有场景并按照A-Z顺序排序，但将"未分类"放在最后
let allScenes = Object.keys(groupedPages)
  .filter(scene => scene !== '未分类')
  .sort((a, b) => a.localeCompare(b, 'zh-CN'));

// 如果存在"未分类"场景，将其添加到列表末尾
if (groupedPages['未分类']) {
  allScenes.push('未分类');
}

// 渲染所有表格
allScenes.forEach(changjing => {
  // 按重要性排序
  groupedPages[changjing].sort((a, b) => (b.zhongyaochengdu || 0) - (a.zhongyaochengdu || 0));

  dv.header(3, `${changjing} (${groupedPages[changjing].length})`);
  dv.table(
    ["任务", "现有场景", "更新场景", "截止日期"],
    groupedPages[changjing].map(p => [
      dv.fileLink(p.file.path, false, p.file.name),
      p.changjing || '未分类',
      createSceneInput(p),
      p.duedate || ''
    ])
  );
});

// 添加CSS样式以固定表头
const style = document.createElement('style');
style.textContent = `
  .dataview.table-view-table thead {
    position: sticky;
    top: 0;
    background-color: var(--background-primary);
    z-index: 1;
  }
`;
document.head.appendChild(style);

```

# 时间线
###  大的图景上的规划




```dataviewjs
// Set the date range for the x-axis
const startDate = dv.date("2024-07-06");
const endDate = dv.date("2024-12-31");
const totalDays = (endDate - startDate) / (1000 * 60 * 60 * 24);

// Get all pages with gaocengji: true and sort them
const projects = dv.pages()
    .where(p => p.gaocengji === true)
    .sort(p => p.qishiriqidate);

// Create the chart
dv.paragraph(createChart(projects));

function createChart(projects) {
    const chartWidth = 2000; // Increased chart width
    const rowHeight = 30;
    const labelWidth = 150;
    const dateHeight = 100; // Height for vertical date labels
    const today = dv.date("today");

    let chart = `<div style="display: flex;">
        <div style="width: ${labelWidth}px; position: relative;">`;

    // Add project labels as clickable links on the left
    projects.forEach((p, index) => {
        chart += `<div style="position: absolute; left: 5px; top: ${(index + 1) * rowHeight + dateHeight}px; width: ${labelWidth - 10}px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            <a href="${p.file.path}" title="${p.file.name}">${p.file.name}</a>
        </div>`;
    });

    chart += `</div>
        <div style="width: calc(100% - ${labelWidth}px); overflow-x: auto;">
            <div style="width: ${chartWidth}px; height: ${(projects.length + 1) * rowHeight + dateHeight}px; position: relative;">`;

    // Create week labels and vertical lines
    let currentDate = new Date(startDate.toJSDate());
    let prevMonday = null;
    while (currentDate <= endDate.toJSDate()) {
        const daysPassed = (currentDate - startDate.toJSDate()) / (1000 * 60 * 60 * 24);
        const left = (daysPassed / totalDays) * chartWidth;
        
        if (currentDate.getDay() === 1) { // Monday
            // Add vertical line for Monday
            chart += `<div style="position: absolute; left: ${left}px; top: ${dateHeight}px; bottom: 0; width: 1px; background-color: #ddd;"></div>`;
            
            // Add date label
            chart += `<div style="position: absolute; left: ${left}px; top: 0; transform: translateX(-50%);">
                <div style="white-space: nowrap; font-size: 10px;">
                    ${formatDate(currentDate)}
                </div>
            </div>`;

            // Add week number label
            if (prevMonday) {
                const prevLeft = ((prevMonday - startDate.toJSDate()) / (1000 * 60 * 60 * 24) / totalDays) * chartWidth;
                const weekNumber = getWeekNumber(prevMonday);
                chart += `<div style="position: absolute; left: ${(left + prevLeft) / 2}px; top: ${dateHeight / 2}px; transform: translateX(-50%);">
                    <div style="white-space: nowrap; font-size: 10px;">
                        W${weekNumber}
                    </div>
                </div>`;
            }
            prevMonday = new Date(currentDate);
        }

        currentDate.setDate(currentDate.getDate() + 1);
    }

    // Add the last week number
    if (prevMonday) {
        const lastLeft = ((prevMonday - startDate.toJSDate()) / (1000 * 60 * 60 * 24) / totalDays) * chartWidth;
        const weekNumber = getWeekNumber(prevMonday);
        chart += `<div style="position: absolute; left: ${(chartWidth + lastLeft) / 2}px; top: ${dateHeight / 2}px; transform: translateX(-50%);">
            <div style="white-space: nowrap; font-size: 10px;">
                W${weekNumber}
            </div>
        </div>`;
    }

    // Add red line for current date
    const todayOffset = ((today - startDate) / (endDate - startDate)) * chartWidth;
    if (todayOffset >= 0 && todayOffset <= chartWidth) {
        chart += `<div style="position: absolute; left: ${todayOffset}px; top: ${dateHeight}px; bottom: 0; width: 2px; background-color: red; z-index: 1;"></div>`;
    }

    // Create project bars
    projects.forEach((p, index) => {
        const start = p.qishiriqidate ? dv.date(p.qishiriqidate) : null;
        const end = p.duedate ? dv.date(p.duedate) : null;
        
        if (start && end) {
            const projectStart = Math.max(0, ((start - startDate) / (endDate - startDate)) * chartWidth);
            const projectWidth = Math.min(chartWidth - projectStart, ((end - start) / (endDate - startDate)) * chartWidth);
            
            chart += `<div style="position: absolute; left: 0; top: ${(index + 1) * rowHeight + dateHeight}px; height: ${rowHeight - 5}px; width: ${chartWidth}px;">
                <div style="position: absolute; left: ${projectStart}px; width: ${projectWidth}px; height: 100%; background: blue;">
                    <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: white;">${formatDate(start)}</span>
                    <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: white;">${formatDate(end)}</span>
                </div>`;
            
            // Handle multiple sprints
            if (p.sprints && Array.isArray(p.sprints)) {
                p.sprints.forEach(sprint => {
                    const sprintStart = dv.date(sprint.start);
                    const sprintEnd = dv.date(sprint.end);
                    if (sprintStart && sprintEnd) {
                        const sprintStartOffset = Math.max(0, ((sprintStart - startDate) / (endDate - startDate)) * chartWidth);
                        const sprintWidth = Math.min(chartWidth - sprintStartOffset, ((sprintEnd - sprintStart) / (endDate - startDate)) * chartWidth);
                        
                        chart += `<div class="sprint-bar" style="position: absolute; left: ${sprintStartOffset}px; width: ${sprintWidth}px; height: 100%; background: orange;" title="${sprint.goal || ''}">
                            <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: black;">${formatDate(sprintStart)}</span>
                            <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: black;">${formatDate(sprintEnd)}</span>
                            <span style="position: absolute; left: 2px; bottom: 2px; font-size: 8px; color: black; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: calc(100% - 4px);">${sprint.goal || ''}</span>
                        </div>`;
                    }
                });
            }
            
            chart += `</div>`;
        }
    });
    
    chart += `</div></div></div>`;

    // Add CSS for hover effect
    chart += `
    <style>
    .sprint-bar {
        position: relative;
    }
    .sprint-bar:hover::after {
        content: attr(title);
        position: absolute;
        left: 50%;
        top: 100%;
        transform: translateX(-50%);
        background: white;
        border: 1px solid black;
        padding: 5px;
        z-index: 1000;
        white-space: nowrap;
    }
    </style>`;

    return chart;
}

function formatDate(date) {
    if (!date) return '';
    return date instanceof Date ? `${date.getMonth() + 1}-${date.getDate()}` : date.toFormat ? date.toFormat('MM-dd') : '';
}

function getWeekNumber(d) {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay()||7));
    var yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
    var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
    return weekNo;
}

```

### 项目截止日期
- 给ASAP添加cstart，cend，duedate，qishiriqidate即可,，应当是不限制非得atomle的，有这四个属性就是项目标配
```dataviewjs
// Set the date range for the x-axis
const startDate = dv.date("2024-07-06");
const endDate = dv.date("2024-07-31");
const totalDays = (endDate - startDate) / (1000 * 60 * 60 * 24);

// Get all pages with cstart and sort them
const projects = dv.pages()
    .where(p => p.cstart)
    .sort(p => p.qishiriqidate);

// Create the chart
dv.paragraph(createChart(projects));

function createChart(projects) {
    const chartWidth = 800;
    const rowHeight = 30;
    const labelWidth = 150;
    const dateHeight = 80; // Height for vertical date labels
    const today = dv.date("today");

    let chart = `<div style="display: flex;">
        <div style="width: ${labelWidth}px; position: relative;">`;

    // Add project labels as clickable links on the left
    projects.forEach((p, index) => {
        chart += `<div style="position: absolute; left: 5px; top: ${(index + 1) * rowHeight + dateHeight}px; width: ${labelWidth - 10}px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
            <a href="${p.file.path}" title="${p.file.name}">${p.file.name}</a>
        </div>`;
    });

    chart += `</div>
        <div style="width: ${chartWidth}px; overflow-x: auto;">
            <div style="width: 100%; height: ${(projects.length + 1) * rowHeight + dateHeight}px; position: relative;">`;

    // Create date labels and vertical lines
    for (let i = 0; i <= totalDays; i++) {
        const date = new Date(startDate.plus({days: i}).toJSDate());
        const left = (i / totalDays) * 100;
        
        // Determine if this is the current day
        const isToday = date.toDateString() === today.toJSDate().toDateString();
        const lineColor = isToday ? "red" : "#ddd";
        
        // Add vertical line for each day
        chart += `<div style="position: absolute; left: ${left}%; top: ${dateHeight}px; bottom: 0; width: 1px; background-color: ${lineColor};"></div>`;
        
        // Add vertical date label for each day, shifted one position to the left
        if (i > 0) { // Skip the first position
            chart += `<div style="position: absolute; left: ${(i - 1) / totalDays * 100}%; top: 0; width: 20px; height: ${dateHeight}px; transform: translateX(-50%);">
                <div style="transform: rotate(-90deg); transform-origin: left bottom; position: absolute; bottom: 0; left: 50%; white-space: nowrap; font-size: 10px;">
                    ${date.toISOString().split('T')[0]}
                </div>
            </div>`;
        }
    }

    // Create project bars
    projects.forEach((p, index) => {
        const start = p.qishiriqidate;
        const end = p.duedate;
        const sprintStart = p.cstart;
        const sprintEnd = p.cend;
        
        const projectStart = ((start - startDate) / (endDate - startDate)) * 100;
        const projectWidth = ((end - start) / (endDate - startDate)) * 100;
        const sprintStartOffset = ((sprintStart - startDate) / (endDate - startDate)) * 100;
        const sprintWidth = ((sprintEnd - sprintStart) / (endDate - startDate)) * 100;
        
        chart += `<div style="position: absolute; left: 0; top: ${(index + 1) * rowHeight + dateHeight}px; height: ${rowHeight - 5}px; width: 100%;">
            <div style="position: absolute; left: ${projectStart}%; width: ${projectWidth}%; height: 100%; background: blue;">
                <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: white;">${start.toFormat('MM-dd')}</span>
                <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: white;">${end.toFormat('MM-dd')}</span>
            </div>
            <div style="position: absolute; left: ${sprintStartOffset}%; width: ${sprintWidth}%; height: 100%; background: orange;">
                <span style="position: absolute; left: 2px; top: 2px; font-size: 8px; color: black;">${sprintStart.toFormat('MM-dd')}</span>
                <span style="position: absolute; right: 2px; bottom: 2px; font-size: 8px; color: black;">${sprintEnd.toFormat('MM-dd')}</span>
            </div>
        </div>`;
    });
    
    chart += `</div></div></div>`;
    return chart;
}

```
#### 附送一个筛选器
```dataview
TABLE file.path AS "File Path", qishiriqidate AS "Start Date", cstart AS "Custom Start", cend AS "Custom End", duedate AS "Due Date"
FROM "项目"

WHERE 
  qishiriqidate AND
  (
    ((cstart != null OR cend != null) AND (cstart = null OR cend = null))
    OR
    (cstart != null AND cend != null AND duedate = null)
  )



SORT file.path ASC

```

```dataviewjs
// Get all files with the 'cstart' property
let pages = dv.pages()
  .where(p => p.cstart)
  .sort(p => p.cstart, 'asc');

// Function to create input field and update button
function createInputField(page, property) {
  const input = document.createElement('input');
  input.type = 'date';
  input.style.width = '120px';
  input.value = page[property] || '';
  
  const button = document.createElement('button');
  button.textContent = '更新';
  button.onclick = async () => {
    const newValue = input.value;
    if (newValue) {
      try {
        const file = app.vault.getAbstractFileByPath(page.file.path);
        if (file && file instanceof obsidian.TFile) {
          const fileContent = await app.vault.read(file);
          let updatedContent;
          
          const frontmatterRegex = /^---\n([\s\S]*?)\n---/;
          const frontmatterMatch = fileContent.match(frontmatterRegex);
          
          if (frontmatterMatch) {
            let frontmatter = frontmatterMatch[1];
            const propertyRegex = new RegExp(`${property}:\\s*(.*)`);
            if (frontmatter.match(propertyRegex)) {
              frontmatter = frontmatter.replace(propertyRegex, `${property}: ${newValue}`);
            } else {
              frontmatter += `\n${property}: ${newValue}`;
            }
            updatedContent = fileContent.replace(frontmatterRegex, `---\n${frontmatter}\n---`);
          } else {
            updatedContent = `---\n${property}: ${newValue}\n---\n\n${fileContent}`;
          }
          
          await app.vault.modify(file, updatedContent);
          console.log(`Updated ${property} to ${newValue} for ${page.file.name}`);
          
          setTimeout(() => {
            dv.refresh();
          }, 100);
        } else {
          console.error(`File not found: ${page.file.path}`);
        }
      } catch (error) {
        console.error(`Error updating ${property} for ${page.file.name}:`, error);
      }
    }
  };
  
  const div = document.createElement('div');
  div.appendChild(input);
  div.appendChild(button);
  return div;
}

// Create a table with the update functionality for all four properties
dv.table(
  ["笔记", "cstart", "更新cstart", "cend", "更新cend", "qishiriqidate", "更新qishiriqidate", "duedate", "更新duedate"],
  pages.map(p => [
    dv.fileLink(p.file.path, false, p.file.name),
    p.cstart || '',
    createInputField(p, 'cstart'),
    p.cend || '',
    createInputField(p, 'cend'),
    p.qishiriqidate || '',
    createInputField(p, 'qishiriqidate'),
    p.duedate || '',
    createInputField(p, 'duedate')
  ])
);

```


# 在这里编辑情报


## 重要系数、截止日期&预计完成需要小时数

```dataviewjs

// Get all files from the "项目" folder with required metadata
let pages = dv.pages('"项目"')
  .where(p => p.qishiriqidate && p.atomle)
  .sort(p => p.zhongyaochengdu, 'desc');

// Function to create input field and update button
function createInputField(page, property, type = 'number') {
  const input = document.createElement('input');
  input.type = type;
  input.style.width = type === 'date' ? '100px' : '50px';
  input.value = page[property] || '';
  
  const button = document.createElement('button');
  button.textContent = '更新';
  button.onclick = async () => {
    const newValue = input.value;
    if (newValue) {
      try {
        const file = app.vault.getAbstractFileByPath(page.file.path);
        if (file && file instanceof obsidian.TFile) {
          const fileContent = await app.vault.read(file);
          let updatedContent;
          
          const frontmatterRegex = /^---\n([\s\S]*?)\n---/;
          const frontmatterMatch = fileContent.match(frontmatterRegex);
          
          if (frontmatterMatch) {
            let frontmatter = frontmatterMatch[1]; // 获取匹配的内容
            const propertyRegex = new RegExp(`${property}:\\s*(.*)`);
            if (frontmatter.match(propertyRegex)) {
              frontmatter = frontmatter.replace(propertyRegex, `${property}: ${newValue}`);
            } else {
              frontmatter += `\n${property}: ${newValue}`;
            }
            updatedContent = fileContent.replace(frontmatterRegex, `---\n${frontmatter}\n---`);
          } else {
            updatedContent = `---\n${property}: ${newValue}\n---\n\n${fileContent}`;
          }
          
          await app.vault.modify(file, updatedContent);
          console.log(`Updated ${property} to ${newValue} for ${page.file.name}`);
          
          setTimeout(() => {
            dv.refresh();
          }, 100);
        } else {
          console.error(`File not found: ${page.file.path}`);
        }
      } catch (error) {
        console.error(`Error updating ${property} for ${page.file.name}:`, error);
      }
    }
  };
  
  const div = document.createElement('div');
  div.appendChild(input);
  div.appendChild(button);
  return div;
}

// Function to highlight overdue dates
function highlightOverdue(date) {
  if (!date) return '';
  const today = new Date();
  const dueDate = new Date(date);
  if (dueDate < today) {
    return `<span style="background-color: #ffcccb; color: #ff0000; font-weight: bold;">${date}</span>`;
  }
  return date;
}

// Create a table with the update functionality for all three properties
dv.table(
  ["笔记", "重要程度", "更新重要程度", "截止", "更新截止", "小时数", "更新小时数"],
  pages.map(p => [
    dv.fileLink(p.file.path, false, p.file.name),
    p.zhongyaochengdu || '',
    createInputField(p, 'zhongyaochengdu'),
    highlightOverdue(p.duedate),
    createInputField(p, 'duedate', 'date'),
    p.yujishiyongshijianxiaoshishu || '',
    createInputField(p, 'yujishiyongshijianxiaoshishu')
  ])
);

```

