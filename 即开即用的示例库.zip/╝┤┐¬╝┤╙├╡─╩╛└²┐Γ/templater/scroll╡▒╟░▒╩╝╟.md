<%*
// 获取当前打开的笔记名称
const currentFileName = tp.file.title;

// 等待一段时间，确保页面内容已经完全加载
await new Promise(resolve => setTimeout(resolve, 200));

// 在整个页面中搜索匹配的文本
let foundInPage = false;
let elements = document.body.getElementsByTagName('*');

for (let i = 0; i < elements.length; i++) {
    if (elements[i].textContent.includes(currentFileName)) {
        foundInPage = true;
        break;
    }
}

// 查找编号列表
let rows = document.querySelectorAll('.custom-table tbody tr');
let foundInList = false;

for (let i = 0; i < rows.length; i++) {
    let row = rows[i];
    let link = row.querySelector('.filename-column a');
    if (link && link.textContent === currentFileName) {
        foundInList = true;
        break;
    }
}

// 如果在页面中找到但不在当前编号列表中
if (foundInPage && !foundInList) {
    // 获取滚动容器（假设是 .workspace-leaf-content）
    const scrollContainer = document.querySelector('.workspace-leaf-content');
    if (scrollContainer) {
        const containerHeight = scrollContainer.clientHeight;
        const currentScroll = scrollContainer.scrollTop;
        const newScroll = (currentScroll > containerHeight / 2) 
            ? containerHeight / 4  // 如果在下半部分，滚动到上四分之一
            : containerHeight * 3 / 4;  // 如果在上半部分，滚动到下四分之一
        
        scrollContainer.scrollTo({
            top: newScroll,
            behavior: 'smooth'
        });
        
        // 等待滚动完成
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
}

// 再次查找并滚动到编号列表中的位置
for (let i = 0; i < rows.length; i++) {
    let row = rows[i];
    let link = row.querySelector('.filename-column a');
    if (link && link.textContent === currentFileName) {
        row.scrollIntoView({ behavior: 'smooth', block: 'center' });
        new Notice(`已找到并滚动到当前笔记：${currentFileName}（第 ${i + 1} 行）`);
        foundInList = true;
        break;
    }
}

if (!foundInList) {
    new Notice(`在编号列表中未找到当前笔记：${currentFileName}`);
}
%>