

function testFunction() {
  return "Test successful!";
}

module.exports = testFunction;
