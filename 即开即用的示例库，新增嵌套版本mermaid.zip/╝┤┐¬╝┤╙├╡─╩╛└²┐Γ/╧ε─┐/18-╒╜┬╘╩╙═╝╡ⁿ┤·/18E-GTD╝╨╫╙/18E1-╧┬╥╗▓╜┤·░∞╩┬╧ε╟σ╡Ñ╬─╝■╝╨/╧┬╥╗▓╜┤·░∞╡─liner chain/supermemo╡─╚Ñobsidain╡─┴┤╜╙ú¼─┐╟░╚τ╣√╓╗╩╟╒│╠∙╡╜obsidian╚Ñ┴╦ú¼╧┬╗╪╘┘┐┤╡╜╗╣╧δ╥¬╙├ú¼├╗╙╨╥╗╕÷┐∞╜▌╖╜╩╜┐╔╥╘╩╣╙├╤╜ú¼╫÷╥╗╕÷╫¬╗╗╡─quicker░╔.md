- [日和周总结 20240630003029](file:///G:/需要备份的区域（热）/最新的/supermemo/知识库/temp/SuperMemoElementNo=(2634))再复制来是这样的
- 转换为<a href="SuperMemoElementNo=(2634)">日和周总结，这种形式

  <a href="SuperMemoElementNo=(2634)">日和周总结

- 复制过来取得号，然后使用快捷键——编辑文本
- 然后复制过去
