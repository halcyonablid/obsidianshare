---
qishiriqidate: 2024-08-03
atomle: true
number: 28
---



parent::[[S-supermemo当中的概念]]