
## 完成atom化的了
```dataview
TABLE 
 (date(today) - date(qishiriqidate)).days AS "DAY SINCE",qishiriqidate AS "起始日期",changjing AS "场景"
FROM "项目"
WHERE qishiriqidate and atomle
SORT (date(today) - date(qishiriqidate)).days DESC
```
距离起始
```dataviewjs

// 获取包含 qishiriqidate 的页面 
let pages = dv.pages('"项目"') 
 .where(p => p.qishiriqidate &&  p.atomle) 
 .sort(p => new Date() - new Date(p.qishiriqidate), 'desc'); 
// 获取标签和数据
let labels = pages.map(p => p.file.name); 
let data = pages.map(p => Math.floor((new Date() - new Date(p.qishiriqidate)) / (1000 * 60 * 60 * 24))); 
// 生成背景颜色数组 
let backgroundColor = pages.map(p => p.qidianbu === true ? 'yellow' : 'rgba(54, 162, 235, 0.5)');
// 生成图表 
dv.paragraph(`\`\`\`chart 
type: bar 
labels: [${labels.map(l => `"${l}"`).join(", ")}] 
series: 
- title: "Days Since" 
- data: [${data.join(", ")}] 
- backgroundColor: [${backgroundColor.map(c => `"${c}"`).join(", ")}]
width: 100% 
height: 1000
\`\`\``);
```
## atomle的截止日期
``` dataviewjs
// Get pages with "项目" tag and a duedate or qishiriqidate, sorted by date descending
let pages = dv.pages('"项目"')
  .where(p => (p.duedate || p.qishiriqidate) &&  p.atomle)
  .sort(p => new Date() - new Date(p.qishiriqidate), 'desc');  

// Get labels (file names) and data (days since duedate or qishiriqidate)
let labels = pages.map(p => p.file.name);
let duedateData = pages.map(p => p.duedate ? Math.floor((new Date(p.duedate) - new Date()) / (1000 * 60 * 60 * 24)) : null);
let qishiriqidateData = pages.map(p => p.qishiriqidate ? Math.floor((new Date() - new Date(p.qishiriqidate)) / (1000 * 60 * 60 * 24)) : null);

// Generate background colors based on qidianbu property
let backgroundColor = pages.map(p => p.qidianbu === true ? 'yellow' : 'rgba(54, 162, 235, 0.5)');

// Generate combined chart
dv.paragraph(`\`\`\`chart
type: bar
labels: [${labels.map(l => `"${l}"`).join(", ")}]
series:
- title: "Days Since duedate"
  data: [${duedateData.join(", ")}]
- title: "Days Since qishiriqidate"
  data: [${qishiriqidateData.join(", ")}]
backgroundColor: [${backgroundColor.map(c => `"${c}"`).join(", ")}]
width: 100%
height: 1000
\`\`\``);

```
```dataview
TABLE 
 (date(duedate) - date(today)).days AS "DAY remain",duedate AS "截止",changjing AS "场景"
FROM "项目"
WHERE qishiriqidate and atomle
SORT (date(duedate) - date(today)).days DESC
```
距离截止
```dataviewjs

// 获取包含 qishiriqidate 的页面 
let pages = dv.pages('"项目"') 
.where(p => p.duedate && p.atomle) 
.sort(p =>  new Date() - new Date(p.duedate) , 'desc'); 
// 获取标签和数据
let labels = pages.map(p => p.file.name); 
let data = pages.map(p => Math.floor((new Date(p.duedate) - new Date() + 1) / (1000 * 60 * 60 * 24))); 
// 生成背景颜色数组 
let backgroundColor = pages.map(p => p.qidianbu === true ? 'yellow' : 'rgba(54, 162, 235, 0.5)');
// 生成图表 
dv.paragraph(`\`\`\`chart 
type: bar 
labels: [${labels.map(l => `"${l}"`).join(", ")}] 
series: 
- title: "Days Since" 
- data: [${data.join(", ")}] 
- backgroundColor: [${backgroundColor.map(c => `"${c}"`).join(", ")}]
width: 100% 
height: 1000
\`\`\``);
```

## 区间分布
```dataviewjs

// 获取包含 qishiriqidate 的页面 
let pages = dv.pages('"项目"') 
.where(p => p.qishiriqidate && p.atomle) 
.array(); 

// 计算每个项目的天数 
let daysSince = pages.map(p => Math.floor((new Date() - new Date(p.qishiriqidate)) / (1000 * 60 * 60 * 24))); 
// 定义日期区间
let intervals = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50]; 
// 统计每个区间的任务数量 
let counts = new Array(intervals.length).fill(0); 
daysSince.forEach(days => {
 for (let i = 0; i < intervals.length; i++) { 
  if (days >= intervals[i] && (i === intervals.length - 1 || days < intervals[i+1])) { 
   counts[i]++; 
   break; 
   } 
   } 
   }); 
// 生成标签 
let labels = intervals.map((val, index) => 
 index === intervals.length - 1 ? `${val}+` : `${val}-${intervals[index+1]-1}` ); 
// 生成图表
dv.paragraph(`\`\`\`chart 
type: bar 
labels: [${labels.map(l => `"${l}"`).join(", ")}] 
series: 
- title: "任务数量" 
- data: [${counts.join(", ")}]
width: 100% 
height: 400 

 \`\`\``);
```
## 任务场景分布
```dataview
TABLE 
 rows.file.link as "任务",rows.duedate as "截止日期"
FROM "项目"
WHERE changjing and atomle
SORT (date(today) - date(qishiriqidate)).days DESC
group by changjing as "场景"
```
## 重要性

```dataview
TABLE 
 zhongyaochengdu AS "重要程度"
FROM "项目"
WHERE qishiriqidate and atomle
sort zhongyaochengdu DESC
```


## 密度排序
```dataview
TABLE 
 zhongyaochengdu/yujishiyongshijianxiaoshishu AS "密度",zhongyaochengdu as "重要程度",yujishiyongshijianxiaoshishu as "小时数" 
FROM "项目"
WHERE qishiriqidate and atomle
sort zhongyaochengdu/yujishiyongshijianxiaoshishu DESC
```



## 并且参见截止日期来进行决策
```dataview
TABLE 
 (date(duedate) - date(today)).days AS "DAY remain",duedate AS "截止"
FROM "项目"
WHERE duedate and atomle
SORT (date(duedate) - date(today)).days asc
```
