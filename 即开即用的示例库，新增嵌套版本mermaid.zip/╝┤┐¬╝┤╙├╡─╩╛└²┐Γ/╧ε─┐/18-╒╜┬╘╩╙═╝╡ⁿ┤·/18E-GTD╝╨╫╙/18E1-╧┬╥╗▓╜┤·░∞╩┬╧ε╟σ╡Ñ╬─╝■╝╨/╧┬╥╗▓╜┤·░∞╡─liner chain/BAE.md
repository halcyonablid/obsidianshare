YANGhaohan962@@@  密码
账号是邮箱


网址：https://mysupport.us.baesystems.com/ext/f?p=114400:3500:3258854122078::::: 



- 
- 
![[Pasted image 20240801151841.png]]
- 
- 
- 需要外网，韩姐给我发网站
- https://mysupport.us.baesystems.com/ext/f?p=114400:102:8945452441617:::102::&cs=3nxl3Cvu4ficu5-OYAKRw_-iv878Ayxw6Wl396QXPilytzBOqZWo7KRxQmvjmPml_YFRCLPa9LrLivjQf07UGSg  从这里进行注册新的账号




![[Pasted image 20240711101544.png]]
