---
qishiriqidate: 2024-06-26
changjing:
  - 整理资料的
benzhoukanguole: true
---
## 整合成立大会

给导师发一个消息
看看是不是可以尝试一下语音转文字，然后转文稿的那个功能

