---
qishiriqidate: 2024-06-27
changjing:
  - 待学
atomle: true
zhongyaochengdu: 15
color: 深紫色
yujishiyongshijianxiaoshishu: 3
---
AID非法，CFDS当中说明的，这个是什么意思
地面测试手段，是不是要使用上，怎么可以复现01多重的故障信息
