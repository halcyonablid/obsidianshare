---
qishiriqidate: 2024-08-03
atomle: false
number: 11
---



parent::[[S-supermemo当中的概念]]