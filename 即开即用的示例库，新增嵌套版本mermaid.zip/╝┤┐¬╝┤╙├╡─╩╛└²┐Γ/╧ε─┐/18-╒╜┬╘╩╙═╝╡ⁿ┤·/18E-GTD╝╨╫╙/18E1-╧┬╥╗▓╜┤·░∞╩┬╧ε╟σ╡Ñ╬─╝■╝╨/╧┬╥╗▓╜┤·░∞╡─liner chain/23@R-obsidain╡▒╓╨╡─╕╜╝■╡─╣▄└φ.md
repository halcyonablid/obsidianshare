

![[23@R-obsidain当中的附件的管理_image_1.png]]
![[23@R-obsidain当中的附件的管理_image_2.png]]
# Attachment Name Formatting
当前新添加一个附件，其名字会按照笔记来进行命名，而不是原来的乱七八糟的什么截图啊什么的格式了
