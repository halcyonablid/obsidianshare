- https://lab.cortexfutura.com/c/support-tanarian-brain/tana-core-and-the-brain


<a href="SuperMemoElementNo=(3113)">tana

tana brain的教程
20240721191840</a>



- Mastering Tana Core是有这个的课程
- 以及Tanarian Brain 两个课程的
![[Pasted image 20240719185325.png]]
两边进行的 ^06fbyd


