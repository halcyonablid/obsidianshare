---
title: 链接转换器
---

<%*
// 获取当前选中的文本
let selectedText = editor.getSelectedText();

// 正则表达式匹配Obsidian链接格式
let regex = /$$([^$$]+)\]$about:SuperMemoElementNo=\((\d+)$\)/;

// 使用正则表达式提取链接文本和元素编号
let match = selectedText.match(regex);

if (match) {
    // 构建HTML链接格式
    let htmlLink = `<a href="SuperMemoElementNo=(${match[2]})">${match[1]}</a>`;

    // 替换选中文本为HTML链接
    editor.replaceSelection(htmlLink);
    // 显示成功通知
    new Notice('链接转换成功');
} else {
    // 如果没有匹配到，输出错误信息
    new Notice('没有选中有效的Obsidian链接');
}
%>

# 链接转换结果
请查看通知确认转换状态。
