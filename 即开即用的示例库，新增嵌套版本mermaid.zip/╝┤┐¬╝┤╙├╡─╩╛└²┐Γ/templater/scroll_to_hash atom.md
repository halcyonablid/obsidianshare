<%*
// 获取用户输入的哈希值
let targetHash = await tp.system.prompt("请输入要查找的哈希值：");
targetHash = parseInt(targetHash);

// 使用 Obsidian API 获取所有文件
const files = app.vault.getMarkdownFiles();

// 查找匹配的文件
let foundFile = null;
for (let file of files) {
    const content = await app.vault.read(file);
    const frontmatter = app.metadataCache.getFileCache(file)?.frontmatter;
    if (frontmatter && frontmatter.哈希 === targetHash) {
        foundFile = file;
        break;
    }
}

if (foundFile) {
    // 等待一段时间，确保表格已经渲染完成
    await new Promise(resolve => setTimeout(resolve, 500));

    // 查找对应的表格行
    let rows = document.querySelectorAll('.custom-table tbody tr');
    for (let i = 0; i < rows.length; i++) {
        let row = rows[i];
        let link = row.querySelector('.filename-column a');
        if (link && link.textContent === foundFile.basename) {
            // 找到匹配的行，滚动到该位置
            row.scrollIntoView({ behavior: 'smooth', block: 'center' });
            new Notice(`已找到哈希值为 ${targetHash} 的笔记：${foundFile.basename}（第 ${i + 1} 行）`);
            break;
        }
    }
} else {
    new Notice(`未找到哈希值为 ${targetHash} 的笔记。`);
}
%>